import { useState } from 'react';
import { 
  Bell, 
  Calendar, 
  ChevronRight, 
  Flame, 
  Microscope, 
  GraduationCap, 
  Compass, 
  FileText,
  Filter
} from 'lucide-react';
import { ANNOUNCEMENTS } from '../data';
import { Announcement } from '../types';

interface AnnouncementsProps {
  onNavigateTo: (sectionId: string) => void;
}

export default function Announcements({ onNavigateTo }: AnnouncementsProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedNotice, setSelectedNotice] = useState<Announcement | null>(null);

  const categories = ['All', 'Admissions', 'Academic', 'Research', 'Events'];

  const filteredAnnouncements = selectedCategory === 'All'
    ? ANNOUNCEMENTS
    : ANNOUNCEMENTS.filter(item => item.category === selectedCategory);

  return (
    <section className="py-14 bg-slate-900/40 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Quick Highlights: 4 Cards linking to key areas */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-14">
          <div 
            onClick={() => onNavigateTo('academics')}
            className="group cursor-pointer p-6 rounded-xl bg-white border border-slate-200 shadow-sm hover:shadow-md hover:border-amber-400 transition-all"
          >
            <div className="w-12 h-12 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <GraduationCap className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
              Academic Departments
            </h4>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              Explore 150+ accredited undergraduate, master's, and doctoral disciplines.
            </p>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-600 mt-3 group-hover:gap-1.5 transition-all">
              Browse Programs <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>

          <div 
            onClick={() => onNavigateTo('about')}
            className="group cursor-pointer p-6 rounded-xl bg-white border border-slate-200 shadow-sm hover:shadow-md hover:border-amber-400 transition-all"
          >
            <div className="w-12 h-12 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Microscope className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
              Research & Innovation Hubs
            </h4>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              18 specialized centers in Quantum AI, Precision Medicine, and Clean Tech.
            </p>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 mt-3 group-hover:gap-1.5 transition-all">
              Discover Research <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>

          <div 
            onClick={() => onNavigateTo('admissions')}
            className="group cursor-pointer p-6 rounded-xl bg-white border border-slate-200 shadow-sm hover:shadow-md hover:border-amber-400 transition-all"
          >
            <div className="w-12 h-12 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <FileText className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
              Admissions Portal
            </h4>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              Apply online for Fall 2026, track application status, and view eligibility.
            </p>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 mt-3 group-hover:gap-1.5 transition-all">
              Apply Online <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>

          <div 
            onClick={() => onNavigateTo('tour')}
            className="group cursor-pointer p-6 rounded-xl bg-white border border-slate-200 shadow-sm hover:shadow-md hover:border-amber-400 transition-all"
          >
            <div className="w-12 h-12 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Compass className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-slate-900 group-hover:text-purple-700 transition-colors">
              360° Virtual Campus Tour
            </h4>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              Interactive panoramic hotspots across our 180-acre botanical eco-campus.
            </p>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-purple-700 mt-3 group-hover:gap-1.5 transition-all">
              Start Tour <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>

        {/* Notice Board Header & Filterable Announcements */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          
          <div className="p-6 bg-slate-900 text-white flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-amber-500 text-slate-950">
                <Bell className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xl font-bold font-academic text-white">
                  University Notice Board & Live Bulletins
                </h3>
                <p className="text-xs text-slate-300">
                  Real-time updates on examinations, admission cut-offs, conferences, and student circulars.
                </p>
              </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs text-slate-400 flex items-center gap-1 mr-1">
                <Filter className="w-3.5 h-3.5" /> Filter:
              </span>
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                    selectedCategory === cat
                      ? 'bg-amber-500 text-slate-950 font-semibold'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Announcement List */}
          <div className="divide-y divide-slate-100">
            {filteredAnnouncements.map((notice) => (
              <div
                key={notice.id}
                className="p-5 hover:bg-slate-50/80 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    {notice.urgent && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-rose-100 text-rose-700">
                        <Flame className="w-3 h-3 text-rose-600" /> Urgent
                      </span>
                    )}
                    <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 text-slate-700">
                      {notice.category}
                    </span>
                    <span className="text-xs text-slate-500 flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> {notice.date}
                    </span>
                  </div>

                  <h4 className="text-sm sm:text-base font-bold text-slate-900 hover:text-amber-600 transition-colors">
                    {notice.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-600 line-clamp-2">
                    {notice.summary}
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-shrink-0">
                  <button
                    onClick={() => setSelectedNotice(notice)}
                    className="px-3.5 py-1.5 rounded-lg border border-slate-300 hover:border-amber-500 text-slate-700 hover:text-amber-700 text-xs font-semibold transition-colors"
                  >
                    Read Circular
                  </button>
                </div>
              </div>
            ))}
          </div>

        </div>

      </div>

      {/* Notice Detail Modal */}
      {selectedNotice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 relative space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
                Official University Circular · {selectedNotice.category}
              </span>
              <button 
                onClick={() => setSelectedNotice(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-semibold p-1"
              >
                ✕ Close
              </button>
            </div>

            <div className="space-y-2">
              <div className="text-xs text-slate-500 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" /> Published on {selectedNotice.date}
              </div>
              <h3 className="text-lg font-bold text-slate-900 font-academic leading-snug">
                {selectedNotice.title}
              </h3>
            </div>

            <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-200">
              {selectedNotice.summary}
            </p>

            <div className="text-xs text-slate-500 italic">
              Notice issued by the Office of the Registrar & Controller of Examinations, Abishek University.
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setSelectedNotice(null)}
                className="px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800"
              >
                Acknowledge & Close
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
