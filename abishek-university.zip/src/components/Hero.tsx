import { 
  ArrowRight, 
  Award, 
  BookOpen, 
  CheckCircle2, 
  Compass, 
  Globe2, 
  Sparkles, 
  TrendingUp, 
  Users 
} from 'lucide-react';
import { QUICK_STATS, UNIVERSITY_INFO } from '../data';

interface HeroProps {
  onExplorePrograms: () => void;
  onApplyNow: () => void;
  onOpenTour: () => void;
}

export default function Hero({ onExplorePrograms, onApplyNow, onOpenTour }: HeroProps) {
  return (
    <section id="home" className="relative bg-slate-950 text-white overflow-hidden border-b border-slate-800">
      {/* Dynamic Background Academic Motif & Ambient Glows */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-amber-500/30 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 -left-40 w-96 h-96 bg-blue-600/25 rounded-full blur-3xl"></div>
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20 lg:pt-24 lg:pb-28">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Main Headline & CTAs */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-amber-500/30 text-amber-400 text-xs font-semibold uppercase tracking-wider shadow-inner">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>Admissions Open for Academic Year 2026-2027</span>
            </div>

            <div className="space-y-2">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white font-academic leading-tight">
                Empowering Minds, <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500">
                  Shaping the Future
                </span>
              </h1>
              <p className="text-lg sm:text-xl text-slate-300 max-w-2xl font-normal leading-relaxed pt-2">
                Welcome to <strong className="text-white font-semibold">Abishek University</strong>. 
                A world-class epicenter of pedagogical rigor, quantum computing discovery, ethical leadership, 
                and global innovation across 150+ degree programs.
              </p>
            </div>

            {/* Value Checkpoints */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-xs sm:text-sm text-slate-300">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>NAAC A++ Accredited</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>100% Merit Scholarships</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>98.4% Career Placement</span>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-4">
              <button
                id="hero-apply-btn"
                onClick={onApplyNow}
                className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-base shadow-lg shadow-amber-500/20 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>Apply for 2026-27</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              <button
                id="hero-explore-btn"
                onClick={onExplorePrograms}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-white font-semibold text-base border border-slate-700 transition-all"
              >
                <BookOpen className="w-5 h-5 text-amber-400" />
                <span>Explore 150+ Programs</span>
              </button>

              <button
                id="hero-tour-btn"
                onClick={onOpenTour}
                className="inline-flex items-center gap-2 px-5 py-3.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-900/60 text-sm font-medium transition-colors"
              >
                <Compass className="w-4 h-4 text-blue-400" />
                <span>Virtual Campus Tour</span>
              </button>
            </div>
          </div>

          {/* Visual Showcase Card & Campus Glimpse */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none rounded-2xl overflow-hidden border border-slate-700/80 shadow-2xl bg-slate-900">
              <img 
                src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=800&q=80" 
                alt="Abishek University Main Quad & Campus Architecture" 
                className="w-full h-80 object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>
              
              {/* Floating Badge */}
              <div className="absolute top-4 right-4 bg-slate-950/80 backdrop-blur-md border border-amber-500/40 px-3 py-1.5 rounded-lg text-xs font-semibold text-amber-300 flex items-center gap-1.5 shadow-md">
                <Award className="w-4 h-4 text-amber-400" />
                <span>QS Top 100 World Alliance</span>
              </div>

              {/* Card Footer Insights */}
              <div className="p-5 relative space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
                  <span>Innovation Campus · Academic Heights</span>
                  <span className="text-emerald-400 font-medium">Est. 1985</span>
                </div>
                <h3 className="text-white font-academic text-xl font-bold">
                  The Chancellor's Visionary Quad
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Home to 18 interdisciplinary research centers, smart carbon-neutral housing, and collaborative AI innovation clusters.
                </p>
                <div className="flex items-center gap-2 pt-1 text-xs text-amber-400 font-medium">
                  <Globe2 className="w-4 h-4" />
                  <span>Welcoming Scholars from 70+ Countries</span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Live Quick Ticker / Stats Counter Strip */}
        <div className="mt-16 pt-10 border-t border-slate-800/80">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6 text-center">
            {QUICK_STATS.map((stat, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-amber-500/40 transition-colors">
                <div className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-academic tracking-tight">
                  {stat.value}
                </div>
                <div className="text-xs sm:text-sm font-semibold text-white mt-1">
                  {stat.label}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  {stat.change}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
