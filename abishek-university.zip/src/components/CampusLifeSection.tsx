import { useState } from 'react';
import { 
  Check, 
  Sparkles, 
  Star, 
  Quote, 
  Building2, 
  BookOpen, 
  Trophy, 
  Trees, 
  ChevronRight, 
  ChevronLeft 
} from 'lucide-react';
import { FACILITIES, TESTIMONIALS } from '../data';

export default function CampusLifeSection() {
  const [activeTabId, setActiveTabId] = useState<string>(FACILITIES[0].id);
  const [testimonialIdx, setTestimonialIdx] = useState(0);

  const activeFacility = FACILITIES.find(f => f.id === activeTabId) || FACILITIES[0];

  const getTabIcon = (id: string) => {
    switch (id) {
      case 'labs': return <Building2 className="w-4 h-4" />;
      case 'library': return <BookOpen className="w-4 h-4" />;
      case 'sports': return <Trophy className="w-4 h-4" />;
      case 'hostel': return <Trees className="w-4 h-4" />;
      default: return <Sparkles className="w-4 h-4" />;
    }
  };

  return (
    <section id="campus" className="py-20 bg-slate-50 border-b border-slate-200 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-600 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
            Student Life & Infrastructure
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold font-academic text-slate-900">
            Campus Features & World-Class Facilities
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Spanning 180 acres of lush botanical gardens and net-zero energy infrastructure, Abishek University combines cutting-edge experimental facilities with vibrant student community spaces.
          </p>
        </div>

        {/* Interactive Tabbed Gallery */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          
          {/* Facility Tab Buttons */}
          <div className="flex border-b border-slate-200 overflow-x-auto bg-slate-100/60 p-2 gap-2">
            {FACILITIES.map((facility) => (
              <button
                key={facility.id}
                id={`facility-tab-${facility.id}`}
                onClick={() => setActiveTabId(facility.id)}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                  activeTabId === facility.id
                    ? 'bg-white text-slate-950 shadow-sm border border-slate-200/80 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                }`}
              >
                <span className={activeTabId === facility.id ? 'text-amber-600' : 'text-slate-400'}>
                  {getTabIcon(facility.id)}
                </span>
                <span>{facility.tabTitle}</span>
              </button>
            ))}
          </div>

          {/* Tab Content Display */}
          <div className="p-6 sm:p-10">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              {/* Image & Photo Showcase */}
              <div className="lg:col-span-6 relative rounded-2xl overflow-hidden border border-slate-200 shadow-md group">
                <img 
                  src={activeFacility.image} 
                  alt={activeFacility.title}
                  className="w-full h-80 sm:h-96 object-cover object-center group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
                
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-amber-400 mb-1">
                    Featured Facility
                  </div>
                  <h4 className="text-lg font-bold font-academic text-white">
                    {activeFacility.title}
                  </h4>
                </div>
              </div>

              {/* Text Highlights & Stats */}
              <div className="lg:col-span-6 space-y-6">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
                    {activeFacility.tagline}
                  </span>
                  <h3 className="text-2xl font-bold font-academic text-slate-900 mt-1">
                    {activeFacility.title}
                  </h3>
                  <p className="text-sm text-slate-600 mt-3 leading-relaxed">
                    {activeFacility.description}
                  </p>
                </div>

                {/* Highlights Checklist */}
                <div className="space-y-2.5">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-700">
                    Key Specifications & Highlights:
                  </div>
                  <div className="space-y-2">
                    {activeFacility.highlights.map((item, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-700">
                        <div className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Check className="w-3 h-3" />
                        </div>
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quick Metric Stats */}
                <div className="grid grid-cols-3 gap-3 pt-4 border-t border-slate-100">
                  {activeFacility.stats.map((st, sIdx) => (
                    <div key={sIdx} className="bg-slate-50 p-3 rounded-xl text-center border border-slate-100">
                      <div className="text-lg font-bold text-slate-900 font-academic">
                        {st.value}
                      </div>
                      <div className="text-[11px] text-slate-500 font-medium">
                        {st.label}
                      </div>
                    </div>
                  ))}
                </div>

              </div>

            </div>
          </div>

        </div>

        {/* Student Testimonials Carousel & Grid */}
        <div className="space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
                Voices of Abishek Scholars
              </span>
              <h3 className="text-2xl sm:text-3xl font-bold font-academic text-slate-900">
                Student & Alumni Testimonials
              </h3>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setTestimonialIdx(prev => Math.max(0, prev - 1))}
                disabled={testimonialIdx === 0}
                className="p-2 rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => setTestimonialIdx(prev => Math.min(TESTIMONIALS.length - 1, prev + 1))}
                disabled={testimonialIdx === TESTIMONIALS.length - 1}
                className="p-2 rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed"
                aria-label="Next testimonial"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {TESTIMONIALS.map((t, idx) => (
              <div
                key={t.id}
                className={`p-6 rounded-2xl border transition-all flex flex-col justify-between ${
                  idx === testimonialIdx 
                    ? 'bg-slate-900 text-white border-amber-500 shadow-lg scale-[1.02]'
                    : 'bg-white text-slate-800 border-slate-200 shadow-sm hover:border-slate-300'
                }`}
              >
                <div className="space-y-4">
                  {/* Star Rating */}
                  <div className="flex items-center gap-1">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star 
                        key={i} 
                        className="w-4 h-4 fill-amber-400 text-amber-400" 
                      />
                    ))}
                  </div>

                  <p className={`text-xs sm:text-sm leading-relaxed italic ${
                    idx === testimonialIdx ? 'text-slate-200' : 'text-slate-600'
                  }`}>
                    "{t.quote}"
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-200/40 flex items-center gap-3">
                  <img 
                    src={t.avatar} 
                    alt={t.name}
                    className="w-10 h-10 rounded-full object-cover border border-amber-400"
                  />
                  <div>
                    <h5 className={`text-sm font-bold ${idx === testimonialIdx ? 'text-white' : 'text-slate-900'}`}>
                      {t.name}
                    </h5>
                    <div className={`text-[11px] ${idx === testimonialIdx ? 'text-amber-400' : 'text-slate-500'}`}>
                      {t.program}
                    </div>
                    {t.currentCompany && (
                      <div className="text-[10px] text-emerald-400 font-medium">
                        {t.currentCompany}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
