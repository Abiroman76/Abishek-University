import { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Clock, 
  CheckCircle2, 
  BookOpen, 
  Sparkles, 
  ArrowRight, 
  GraduationCap, 
  X,
  Download,
  Briefcase,
  DollarSign
} from 'lucide-react';
import { PROGRAMS } from '../data';
import { AcademicProgram, AcademicField, DegreeLevel } from '../types';

interface AcademicsSectionProps {
  onSelectProgramToApply: (programTitle: string, degreeLevel: string) => void;
}

export default function AcademicsSection({ onSelectProgramToApply }: AcademicsSectionProps) {
  const [selectedDegree, setSelectedDegree] = useState<DegreeLevel>('All');
  const [selectedField, setSelectedField] = useState<AcademicField>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeModalProgram, setActiveModalProgram] = useState<AcademicProgram | null>(null);

  const degreeOptions: DegreeLevel[] = ['All', 'Undergraduate', 'Postgraduate', 'Doctorate'];
  const fieldOptions: AcademicField[] = [
    'All', 
    'Artificial Intelligence', 
    'Engineering & Tech', 
    'Business', 
    'Medicine', 
    'Humanities'
  ];

  const filteredPrograms = useMemo(() => {
    return PROGRAMS.filter((prog) => {
      const matchDegree = selectedDegree === 'All' || prog.degree === selectedDegree;
      const matchField = selectedField === 'All' || prog.field === selectedField;
      const matchSearch = searchQuery.trim() === '' || 
        prog.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prog.shortDesc.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prog.field.toLowerCase().includes(searchQuery.toLowerCase());

      return matchDegree && matchField && matchSearch;
    });
  }, [selectedDegree, selectedField, searchQuery]);

  return (
    <section id="academics" className="py-20 bg-white border-b border-slate-200 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-600 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
            Pedagogy & Disciplines
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold font-academic text-slate-900">
            Academics & Program Finder
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Choose from over 150 industry-accredited undergraduate, master's, and doctoral programs built upon interdisciplinary experimentation, cutting-edge labs, and corporate fellowships.
          </p>
        </div>

        {/* Interactive Filter Control Panel */}
        <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5">
          
          {/* Top Row: Search + Quick Stats */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="program-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search programs by name, keyword, or skill (e.g. AI, Cloud, MBA)..."
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all shadow-sm"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
                >
                  Clear
                </button>
              )}
            </div>

            <div className="text-xs text-slate-500 font-medium">
              Showing <strong className="text-slate-900">{filteredPrograms.length}</strong> programs matching your criteria
            </div>
          </div>

          {/* Degree Level Filter */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-200">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1 mr-2">
              <GraduationCap className="w-3.5 h-3.5" /> Degree:
            </span>
            {degreeOptions.map((deg) => (
              <button
                key={deg}
                onClick={() => setSelectedDegree(deg)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  selectedDegree === deg
                    ? 'bg-slate-900 text-amber-400 shadow-sm'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {deg}
              </button>
            ))}
          </div>

          {/* Field of Study Filter */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-200">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1 mr-2">
              <Filter className="w-3.5 h-3.5" /> Field:
            </span>
            {fieldOptions.map((field) => (
              <button
                key={field}
                onClick={() => setSelectedField(field)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  selectedField === field
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {field}
              </button>
            ))}
          </div>

        </div>

        {/* Programs Grid */}
        {filteredPrograms.length === 0 ? (
          <div className="text-center py-16 bg-slate-50 rounded-2xl border border-dashed border-slate-300">
            <BookOpen className="w-12 h-12 text-slate-400 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-slate-800">No matching programs found</h3>
            <p className="text-sm text-slate-500 mt-1">
              Try adjusting your search keywords or resetting the degree / field filters.
            </p>
            <button
              onClick={() => {
                setSelectedDegree('All');
                setSelectedField('All');
                setSearchQuery('');
              }}
              className="mt-4 px-4 py-2 bg-slate-900 text-amber-400 text-xs font-semibold rounded-lg"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPrograms.map((program) => (
              <div
                key={program.id}
                className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md hover:border-amber-400 transition-all flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  {/* Card Header & Badges */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      <span className="inline-block text-[11px] font-bold uppercase tracking-wider text-amber-600 bg-amber-50 px-2.5 py-0.5 rounded">
                        {program.degree}
                      </span>
                      <div className="text-xs text-slate-500 font-medium">
                        {program.field}
                      </div>
                    </div>
                    {program.badge && (
                      <span className="text-[10px] font-bold uppercase tracking-wide bg-slate-900 text-amber-400 px-2 py-0.5 rounded shadow-xs">
                        {program.badge}
                      </span>
                    )}
                  </div>

                  {/* Title & Short Description */}
                  <h3 className="text-lg font-bold font-academic text-slate-900 group-hover:text-amber-600 transition-colors leading-snug">
                    {program.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {program.shortDesc}
                  </p>

                  {/* Key Program Metrics */}
                  <div className="bg-slate-50 rounded-xl p-3.5 space-y-2 text-xs border border-slate-100">
                    <div className="flex items-center justify-between text-slate-700">
                      <span className="flex items-center gap-1 text-slate-500">
                        <Clock className="w-3.5 h-3.5 text-amber-500" /> Duration:
                      </span>
                      <span className="font-semibold">{program.duration}</span>
                    </div>

                    <div className="flex items-center justify-between text-slate-700">
                      <span className="flex items-center gap-1 text-slate-500">
                        <BookOpen className="w-3.5 h-3.5 text-blue-500" /> Credits:
                      </span>
                      <span className="font-semibold">{program.credits} Credit Hours</span>
                    </div>

                    <div className="flex items-center justify-between text-slate-700">
                      <span className="flex items-center gap-1 text-slate-500">
                        <DollarSign className="w-3.5 h-3.5 text-emerald-500" /> Tuition:
                      </span>
                      <span className="font-semibold text-emerald-700">
                        ${program.tuitionPerSemester.toLocaleString()} / semester
                      </span>
                    </div>
                  </div>

                  {/* Eligibility Teaser */}
                  <div className="text-[11px] text-slate-500 leading-tight">
                    <strong className="text-slate-700">Eligibility:</strong> {program.eligibility}
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="pt-5 mt-5 border-t border-slate-100 flex items-center justify-between gap-2">
                  <button
                    id={`view-syllabus-btn-${program.id}`}
                    onClick={() => setActiveModalProgram(program)}
                    className="text-xs font-bold text-slate-900 hover:text-amber-600 inline-flex items-center gap-1 transition-colors"
                  >
                    <span>View Syllabus</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    id={`card-apply-btn-${program.id}`}
                    onClick={() => onSelectProgramToApply(program.title, program.degree)}
                    className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-sm transition-all"
                  >
                    Apply Now
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>

      {/* Program Syllabus / Curriculum Modal */}
      {activeModalProgram && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 relative p-6 sm:p-8 space-y-6">
            
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-600 bg-amber-50 px-2 py-0.5 rounded">
                    {activeModalProgram.degree}
                  </span>
                  <span className="text-xs text-slate-500">
                    {activeModalProgram.field}
                  </span>
                </div>
                <h3 className="text-2xl font-bold font-academic text-slate-900 mt-1">
                  {activeModalProgram.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveModalProgram(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Overview Details */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl text-xs text-slate-700 border border-slate-100">
              <div>
                <span className="block text-slate-500">Duration</span>
                <span className="font-bold text-slate-900 text-sm">{activeModalProgram.duration}</span>
              </div>
              <div>
                <span className="block text-slate-500">Total Credits</span>
                <span className="font-bold text-slate-900 text-sm">{activeModalProgram.credits} Semester Units</span>
              </div>
              <div>
                <span className="block text-slate-500">Est. Semester Tuition</span>
                <span className="font-bold text-emerald-700 text-sm">${activeModalProgram.tuitionPerSemester.toLocaleString()}</span>
              </div>
            </div>

            {/* Eligibility & Career Horizon */}
            <div className="space-y-2 text-xs sm:text-sm">
              <div>
                <strong className="text-slate-900">Admission Criteria & Eligibility:</strong>
                <p className="text-slate-600 mt-0.5">{activeModalProgram.eligibility}</p>
              </div>
              <div>
                <strong className="text-slate-900">Career Horizon & Industry Placement:</strong>
                <p className="text-slate-600 mt-0.5">{activeModalProgram.careerOutlook}</p>
              </div>
            </div>

            {/* Semester-by-Semester Curriculum Breakdown */}
            <div className="space-y-4">
              <h4 className="text-base font-bold font-academic text-slate-900 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-amber-500" />
                Comprehensive Syllabus Outline
              </h4>

              <div className="space-y-3">
                {activeModalProgram.syllabus.map((sem) => (
                  <div key={sem.semester} className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                    <div className="text-xs font-bold text-amber-700 uppercase tracking-wide">
                      Semester 0{sem.semester}
                    </div>
                    <div className="text-sm font-semibold text-slate-900 mt-0.5 mb-2">
                      {sem.title}
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {sem.courses.map((course, cIdx) => (
                        <div key={cIdx} className="flex items-center gap-1.5 text-xs text-slate-700">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                          <span>{course}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Modal Bottom Actions */}
            <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs text-slate-500">
                Official syllabus certified by the Academic Council.
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setActiveModalProgram(null)}
                  className="px-4 py-2.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const prog = activeModalProgram;
                    setActiveModalProgram(null);
                    onSelectProgramToApply(prog.title, prog.degree);
                  }}
                  className="px-5 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
                >
                  <span>Apply for this Program</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

          </div>
        </div>
      )}
    </section>
  );
}
