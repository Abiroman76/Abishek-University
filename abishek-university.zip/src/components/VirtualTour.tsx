import { useState } from 'react';
import { 
  Compass, 
  MapPin, 
  Sparkles, 
  Eye, 
  Check, 
  Layers, 
  Maximize2,
  Info
} from 'lucide-react';
import { CAMPUS_HOTSPOTS } from '../data';
import { CampusHotspot } from '../types';

export default function VirtualTour() {
  const [selectedHotspot, setSelectedHotspot] = useState<CampusHotspot>(CAMPUS_HOTSPOTS[0]);
  const [showFullView, setShowFullView] = useState(false);

  return (
    <section id="tour" className="py-20 bg-slate-950 text-white border-b border-slate-800 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-400 bg-slate-900 px-3 py-1 rounded-full border border-amber-500/30">
            Interactive Exploration
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold font-academic text-white">
            Virtual Campus Tour Preview & 360° Hotspots
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Take an interactive walk across our 180-acre smart campus. Click on the pins or hotspot badges below to explore academic landmarks, supercomputing clusters, and Olympic arenas.
          </p>
        </div>

        {/* Main Tour Interactive Container */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left / Top: Interactive Map & Hotspot Pinboard */}
          <div className="lg:col-span-7 bg-slate-900 rounded-3xl p-4 sm:p-6 border border-slate-800 shadow-2xl relative">
            <div className="flex items-center justify-between mb-4 px-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
                <Compass className="w-4 h-4 animate-spin-slow" />
                <span>Interactive Campus Map (180 Acres)</span>
              </div>
              <span className="text-[11px] text-slate-400">
                Click any glowing hotspot to preview
              </span>
            </div>

            {/* Map Canvas with Ambient Aesthetic & Hotspot Pins */}
            <div className="relative w-full h-80 sm:h-96 rounded-2xl overflow-hidden border border-slate-700 bg-slate-950">
              {/* Aerial Campus Backdrop */}
              <img 
                src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1200&q=80" 
                alt="Abishek University Aerial Campus Map" 
                className="w-full h-full object-cover opacity-40 brightness-75 scale-105 transition-transform duration-700 hover:scale-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-slate-950/60"></div>

              {/* Grid overlay */}
              <div className="absolute inset-0 bg-[radial-gradient(#f59e0b15_1px,transparent_1px)] [background-size:16px_16px]"></div>

              {/* Clickable Hotspot Pins */}
              {CAMPUS_HOTSPOTS.map((spot) => {
                const isSelected = selectedHotspot.id === spot.id;
                return (
                  <div
                    key={spot.id}
                    style={{ left: `${spot.x}%`, top: `${spot.y}%` }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 z-20 group"
                  >
                    <button
                      id={`hotspot-pin-${spot.id}`}
                      onClick={() => setSelectedHotspot(spot)}
                      className={`relative flex items-center justify-center p-2 rounded-full transition-all duration-300 focus:outline-none ${
                        isSelected 
                          ? 'bg-amber-500 text-slate-950 scale-125 shadow-lg shadow-amber-500/50 ring-4 ring-amber-400/40' 
                          : 'bg-slate-900/90 text-amber-400 hover:bg-amber-500 hover:text-slate-950 border border-amber-500/40 hover:scale-110'
                      }`}
                      aria-label={`View ${spot.name}`}
                    >
                      <MapPin className="w-4 h-4" />
                      
                      {/* Pulse Wave */}
                      <span className={`absolute inset-0 rounded-full animate-ping pointer-events-none opacity-40 ${
                        isSelected ? 'bg-amber-400' : 'bg-amber-500/30'
                      }`}></span>
                    </button>

                    {/* Tooltip Label */}
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block whitespace-nowrap z-30 pointer-events-none">
                      <div className="bg-slate-900 text-white text-[11px] font-semibold py-1 px-2.5 rounded-md border border-slate-700 shadow-lg">
                        {spot.name}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Hotspot Horizontal Quick Selector Strip */}
            <div className="mt-4 pt-4 border-t border-slate-800 flex items-center gap-2 overflow-x-auto pb-2">
              {CAMPUS_HOTSPOTS.map((spot) => (
                <button
                  key={spot.id}
                  onClick={() => setSelectedHotspot(spot)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                    selectedHotspot.id === spot.id
                      ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{spot.name.split('&')[0]}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Right: Selected Hotspot 360-Style Viewport & Facts */}
          <div className="lg:col-span-5 bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-2xl space-y-6">
            
            {/* Viewport Frame */}
            <div className="relative rounded-2xl overflow-hidden border border-slate-700 shadow-lg group">
              <img 
                src={selectedHotspot.image} 
                alt={selectedHotspot.name}
                className="w-full h-64 object-cover object-center group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent"></div>
              
              <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded-md text-[10px] font-bold text-amber-400 border border-amber-500/30 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>360° Vista Active</span>
              </div>

              <div className="absolute bottom-3 left-3 right-3 text-white">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                  {selectedHotspot.category}
                </span>
                <h4 className="text-lg font-bold font-academic text-white">
                  {selectedHotspot.name}
                </h4>
              </div>
            </div>

            {/* Description & Key Facts */}
            <div className="space-y-4">
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {selectedHotspot.description}
              </p>

              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Key Campus Highlights:
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {selectedHotspot.highlights.map((fact, idx) => (
                    <div key={idx} className="flex items-center gap-1.5 text-xs text-slate-200">
                      <Check className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                      <span>{fact}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Virtual Tour Guidance Note */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center gap-3 text-xs text-slate-400">
              <Info className="w-5 h-5 text-amber-400 flex-shrink-0" />
              <span>
                Guided walking tours depart every Monday through Saturday from the Chancellor Quad Visitor Pavilion.
              </span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
