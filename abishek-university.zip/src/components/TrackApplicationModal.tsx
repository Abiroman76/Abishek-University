import { useState, useEffect } from 'react';
import { 
  X, 
  Search, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  AlertCircle, 
  FileText, 
  Printer, 
  Sparkles,
  ClipboardList
} from 'lucide-react';
import { AdmissionApplication } from '../types';

interface TrackApplicationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function TrackApplicationModal({ isOpen, onClose }: TrackApplicationModalProps) {
  const [appIdInput, setAppIdInput] = useState('');
  const [searchedApp, setSearchedApp] = useState<AdmissionApplication | null>(null);
  const [recentApps, setRecentApps] = useState<AdmissionApplication[]>([]);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (isOpen) {
      try {
        const stored = localStorage.getItem('au_applications');
        if (stored) {
          const parsed: AdmissionApplication[] = JSON.parse(stored);
          setRecentApps(parsed);
          if (parsed.length > 0 && !searchedApp) {
            setSearchedApp(parsed[0]);
            setAppIdInput(parsed[0].id);
          }
        }
      } catch (e) {
        console.warn('Failed to parse applications from localStorage', e);
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSearch = (targetId?: string) => {
    const idToLook = (targetId || appIdInput).trim().toUpperCase();
    setErrorMsg('');
    if (!idToLook) {
      setErrorMsg('Please enter an Application ID (e.g. AU-2026-12345)');
      return;
    }

    try {
      const stored = localStorage.getItem('au_applications');
      const parsed: AdmissionApplication[] = stored ? JSON.parse(stored) : [];
      const found = parsed.find(a => a.id.trim().toUpperCase() === idToLook);
      if (found) {
        setSearchedApp(found);
      } else {
        setErrorMsg(`No record found for Application ID: ${idToLook}. Please verify or submit a new application.`);
        setSearchedApp(null);
      }
    } catch (e) {
      setErrorMsg('Error retrieving records from local storage.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative space-y-6 max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-amber-100 text-amber-800">
              <ClipboardList className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold font-academic text-slate-900">
                Track Application Status
              </h3>
              <p className="text-xs text-slate-500">
                Live verification portal for Abishek University applicants
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Input Search Form */}
        <div className="space-y-2">
          <label className="block text-xs font-semibold text-slate-700">
            Enter Application ID
          </label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={appIdInput}
                onChange={(e) => setAppIdInput(e.target.value)}
                placeholder="e.g. AU-2026-48291"
                className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-xs sm:text-sm uppercase tracking-wider font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <button
              onClick={() => handleSearch()}
              className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-400 font-bold text-xs transition-colors"
            >
              Lookup
            </button>
          </div>
          {errorMsg && <p className="text-xs text-rose-600 mt-1">{errorMsg}</p>}
        </div>

        {/* Quick Pick Recent Applications in LocalStorage if available */}
        {recentApps.length > 0 && (
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
            <span className="text-[11px] font-bold text-slate-600 block">
              Recent Applications on this Device:
            </span>
            <div className="flex flex-wrap gap-2">
              {recentApps.map((a) => (
                <button
                  key={a.id}
                  onClick={() => {
                    setAppIdInput(a.id);
                    handleSearch(a.id);
                  }}
                  className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-all ${
                    searchedApp?.id === a.id
                      ? 'bg-amber-500 text-slate-950 border-amber-500'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  {a.id} ({a.personal.fullName.split(' ')[0]})
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Searched Application Status Display */}
        {searchedApp && (
          <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800 space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                  Application ID
                </span>
                <span className="text-xl font-black font-academic text-amber-400">
                  {searchedApp.id}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] px-2.5 py-1 rounded-full font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 inline-block">
                  {searchedApp.status}
                </span>
                <span className="text-[10px] text-slate-400 block mt-1">
                  Submitted: {searchedApp.submittedAt}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950 p-3 rounded-xl border border-slate-800">
              <div>
                <span className="text-slate-400 block text-[10px]">Candidate:</span>
                <span className="font-semibold text-slate-100">{searchedApp.personal.fullName}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Degree & Major:</span>
                <span className="font-semibold text-slate-100">{searchedApp.academic.desiredMajor}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Previous School:</span>
                <span className="text-slate-300">{searchedApp.academic.previousInstitution}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Reported GPA:</span>
                <span className="text-amber-400 font-bold">{searchedApp.academic.gpa}</span>
              </div>
            </div>

            {/* Verification Stage Milestones */}
            <div className="pt-2 border-t border-slate-800 space-y-2.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                Verification Pipeline:
              </span>
              
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2.5 text-emerald-400">
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                  <span>Dossier & Scanned Documents Received</span>
                </div>
                <div className="flex items-center gap-2.5 text-amber-400">
                  <Clock className="w-4 h-4 flex-shrink-0 animate-pulse" />
                  <span>Academic Transcript Audit (In Progress)</span>
                </div>
                <div className="flex items-center gap-2.5 text-slate-500">
                  <Calendar className="w-4 h-4 flex-shrink-0" />
                  <span>Faculty Admissions Board Review</span>
                </div>
                <div className="flex items-center gap-2.5 text-slate-500">
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                  <span>Official Decision & Scholarship Grant Notice</span>
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-between items-center">
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 text-xs text-slate-300 hover:text-white"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Application Summary</span>
              </button>

              <span className="text-[10px] text-slate-500">
                Official AU Student Record
              </span>
            </div>
          </div>
        )}

        <div className="flex justify-end pt-2">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-900 text-white font-semibold text-xs hover:bg-slate-800 transition-colors"
          >
            Close Tracker
          </button>
        </div>

      </div>
    </div>
  );
}
