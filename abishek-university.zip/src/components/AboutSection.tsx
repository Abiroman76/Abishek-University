import { useState } from 'react';
import { 
  Quote, 
  Target, 
  Eye, 
  ShieldCheck, 
  Award, 
  GraduationCap, 
  CheckCircle2, 
  ChevronRight, 
  ChevronLeft,
  Calendar
} from 'lucide-react';
import { LEADERSHIP, MILESTONES, UNIVERSITY_INFO } from '../data';

export default function AboutSection() {
  const [activeMilestoneIdx, setActiveMilestoneIdx] = useState(MILESTONES.length - 1);

  const chancellor = LEADERSHIP[0];
  const otherLeaders = LEADERSHIP.slice(1);

  return (
    <section id="about" className="py-20 bg-slate-50 border-b border-slate-200 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-600 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
            Heritage, Vision & Governance
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold font-academic text-slate-900">
            About Abishek University
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Established in 1985, Abishek University has evolved from a pioneering regional technology institute into an internationally acclaimed research university shaping ethical leaders for an interconnected world.
          </p>
        </div>

        {/* Chancellor's Welcome & Founder's Message Card */}
        <div className="bg-slate-900 text-white rounded-3xl p-8 lg:p-12 shadow-xl border border-slate-800 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative">
            
            <div className="lg:col-span-5 flex flex-col items-center text-center">
              <div className="relative">
                <div className="w-52 h-52 sm:w-60 sm:h-60 rounded-2xl overflow-hidden border-2 border-amber-500/60 shadow-2xl">
                  <img 
                    src={chancellor.image} 
                    alt={chancellor.name} 
                    className="w-full h-full object-cover object-center"
                  />
                </div>
                <div className="absolute -bottom-3 bg-amber-500 text-slate-950 font-bold text-xs px-4 py-1 rounded-full shadow-md">
                  Founder & Chancellor
                </div>
              </div>
              
              <div className="mt-6 space-y-1">
                <h3 className="text-xl font-bold font-academic text-white">
                  {chancellor.name}
                </h3>
                <p className="text-xs text-amber-400 font-medium">
                  {chancellor.credentials}
                </p>
              </div>
            </div>

            <div className="lg:col-span-7 space-y-6">
              <div className="flex items-center gap-2 text-amber-400">
                <Quote className="w-8 h-8 opacity-70" />
                <span className="text-xs font-semibold uppercase tracking-wider">
                  The Founder's Philosophy
                </span>
              </div>

              <blockquote className="text-lg sm:text-xl font-academic italic text-slate-100 leading-relaxed">
                "{chancellor.message}"
              </blockquote>

              <div className="text-slate-300 text-sm leading-relaxed space-y-3">
                <p>
                  "When we laid the cornerstone of Abishek University four decades ago, our covenant was simple yet radical: to dismantle the artificial barriers between pure humanities and frontier science, providing every curious mind the laboratory access and mentorship to lead global change."
                </p>
                <p>
                  "Today, as our alumni engineer quantum systems, formulate life-saving biotherapies, and counsel world organizations, that covenant burns brighter than ever. Welcome to your intellectual home."
                </p>
              </div>

              <div className="pt-2 flex flex-wrap items-center gap-6 text-xs text-slate-400 border-t border-slate-800">
                <div>
                  <span className="font-bold text-white block text-sm">40+ Years</span>
                  <span>Dedication to STEM & Ethics</span>
                </div>
                <div>
                  <span className="font-bold text-white block text-sm">50,000+</span>
                  <span>Scholars Mentored Worldwide</span>
                </div>
                <div>
                  <span className="font-bold text-white block text-sm">100% Need-Blind</span>
                  <span>Merit Aid Framework</span>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Mission, Vision & Core Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          <div className="bg-white rounded-2xl p-7 border border-slate-200 shadow-sm hover:border-amber-400 transition-all flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                <Target className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold font-academic text-slate-900">
                Our Mission
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                To foster transformative education and high-impact discovery through rigorous interdisciplinary scholarship, ethical curiosity, and inclusive community engagement that solves real-world challenges.
              </p>
            </div>
            <div className="pt-4 border-t border-slate-100 mt-4 text-xs font-semibold text-amber-700">
              Transformative Education · Rigorous Discovery
            </div>
          </div>

          <div className="bg-white rounded-2xl p-7 border border-slate-200 shadow-sm hover:border-blue-400 transition-all flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
                <Eye className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold font-academic text-slate-900">
                Our Vision
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                To stand as a globally recognized preeminent university that defines the benchmark for AI-integrated pedagogy, green sustainability, patent-yielding research, and humane visionary leadership.
              </p>
            </div>
            <div className="pt-4 border-t border-slate-100 mt-4 text-xs font-semibold text-blue-800">
              Global Preeminence · Sustainable Future
            </div>
          </div>

          <div className="bg-white rounded-2xl p-7 border border-slate-200 shadow-sm hover:border-emerald-400 transition-all flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold font-academic text-slate-900">
                Core Values
              </h3>
              <ul className="text-slate-600 text-sm space-y-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  <span><strong>Academic Excellence:</strong> Relentless inquiry.</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  <span><strong>Integrity & Ethics:</strong> Principled stewardship.</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  <span><strong>Global Inclusivity:</strong> 70+ nation diversity.</span>
                </li>
              </ul>
            </div>
            <div className="pt-4 border-t border-slate-100 mt-4 text-xs font-semibold text-emerald-800">
              Excellence · Integrity · Inclusion
            </div>
          </div>

        </div>

        {/* Interactive Campus Timeline / History Milestone Slider */}
        <div className="bg-white rounded-3xl p-8 lg:p-10 border border-slate-200 shadow-sm space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
                Four Decades of Impact
              </span>
              <h3 className="text-2xl font-bold font-academic text-slate-900">
                Milestones in Excellence (1985 – 2026)
              </h3>
            </div>
            
            {/* Nav Arrows */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveMilestoneIdx(prev => Math.max(0, prev - 1))}
                disabled={activeMilestoneIdx === 0}
                className="p-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed"
                aria-label="Previous milestone"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => setActiveMilestoneIdx(prev => Math.min(MILESTONES.length - 1, prev + 1))}
                disabled={activeMilestoneIdx === MILESTONES.length - 1}
                className="p-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed"
                aria-label="Next milestone"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Timeline Bar Buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 border-b border-slate-100 pb-4">
            {MILESTONES.map((m, idx) => (
              <button
                key={m.year}
                onClick={() => setActiveMilestoneIdx(idx)}
                className={`py-2 px-3 rounded-xl text-center text-sm font-semibold transition-all ${
                  activeMilestoneIdx === idx
                    ? 'bg-slate-900 text-amber-400 shadow-sm'
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <div className="text-xs opacity-75">Year</div>
                <div className="text-base font-bold">{m.year}</div>
              </button>
            ))}
          </div>

          {/* Active Milestone Display */}
          <div className="bg-slate-50 rounded-2xl p-6 sm:p-8 border border-slate-200 flex flex-col md:flex-row items-start md:items-center gap-6">
            <div className="w-16 h-16 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold text-2xl font-academic flex-shrink-0 shadow-md">
              {MILESTONES[activeMilestoneIdx].year}
            </div>
            <div className="space-y-2">
              <h4 className="text-xl font-bold font-academic text-slate-900">
                {MILESTONES[activeMilestoneIdx].title}
              </h4>
              <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
                {MILESTONES[activeMilestoneIdx].description}
              </p>
            </div>
          </div>
        </div>

        {/* Leadership & Advisory Board */}
        <div className="space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h3 className="text-2xl sm:text-3xl font-bold font-academic text-slate-900">
              University Leadership & Advisory Council
            </h3>
            <p className="text-xs sm:text-sm text-slate-600">
              Distinguished academicians, scientists, and industry leaders guiding academic policy and student welfare.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {otherLeaders.map((leader, idx) => (
              <div 
                key={idx}
                className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col items-center text-center space-y-4"
              >
                <div className="w-28 h-28 rounded-full overflow-hidden border-2 border-amber-500/50 shadow-sm">
                  <img 
                    src={leader.image} 
                    alt={leader.name} 
                    className="w-full h-full object-cover object-center"
                  />
                </div>
                
                <div className="space-y-1">
                  <h4 className="text-lg font-bold font-academic text-slate-900">
                    {leader.name}
                  </h4>
                  <div className="text-xs font-semibold text-amber-600">
                    {leader.role}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    {leader.credentials}
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {leader.bio}
                </p>

                {leader.message && (
                  <div className="w-full pt-3 border-t border-slate-100 text-[11px] italic text-slate-500">
                    "{leader.message}"
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
