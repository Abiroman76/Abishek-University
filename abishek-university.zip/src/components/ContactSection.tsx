import { useState, FormEvent } from 'react';
import { 
  ChevronDown, 
  Send, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  CheckCircle2, 
  HelpCircle,
  MessageSquare
} from 'lucide-react';
import { FAQS, UNIVERSITY_INFO } from '../data';

export default function ContactSection() {
  const [activeFaqId, setActiveFaqId] = useState<string>(FAQS[0].id);
  const [selectedFaqCategory, setSelectedFaqCategory] = useState<string>('All');

  // Contact Form State
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'General Admissions Inquiry',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const faqCategories = ['All', 'Admissions', 'Financial & Scholarships', 'Academics', 'Campus Life'];

  const filteredFaqs = selectedFaqCategory === 'All'
    ? FAQS
    : FAQS.filter(f => f.category === selectedFaqCategory);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.message.trim()) {
      setError('Please fill in your name, email, and inquiry message.');
      return;
    }
    setError('');
    setSubmitted(true);
  };

  const handleReset = () => {
    setForm({
      name: '',
      email: '',
      phone: '',
      subject: 'General Admissions Inquiry',
      message: ''
    });
    setSubmitted(false);
  };

  return (
    <section id="contact" className="py-20 bg-slate-50 border-b border-slate-200 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
        
        {/* FAQ Section */}
        <div className="space-y-10">
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-bold uppercase tracking-widest text-amber-600 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
              Assistance & Knowledge Base
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold font-academic text-slate-900">
              Frequently Asked Questions (FAQ)
            </h2>
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              Find immediate clarity on application prerequisites, degree accreditation, scholarships, accommodation, and campus visits.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap justify-center gap-2">
            {faqCategories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedFaqCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                  selectedFaqCategory === cat
                    ? 'bg-slate-900 text-amber-400 shadow-sm'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Accordion FAQ items */}
          <div className="max-w-3xl mx-auto space-y-3">
            {filteredFaqs.map((faq) => {
              const isOpen = activeFaqId === faq.id;
              return (
                <div
                  key={faq.id}
                  className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs transition-all"
                >
                  <button
                    onClick={() => setActiveFaqId(isOpen ? '' : faq.id)}
                    className="w-full text-left p-5 flex items-center justify-between gap-4 hover:bg-slate-50/80 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-full bg-amber-50 text-amber-600 text-xs font-bold flex items-center justify-center flex-shrink-0">
                        ?
                      </span>
                      <span className="text-sm sm:text-base font-bold text-slate-900 font-academic">
                        {faq.question}
                      </span>
                    </div>
                    <ChevronDown
                      className={`w-5 h-5 text-slate-400 transition-transform duration-200 flex-shrink-0 ${
                        isOpen ? 'rotate-180 text-amber-600' : ''
                      }`}
                    />
                  </button>

                  {isOpen && (
                    <div className="p-5 pt-0 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/50">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Contact Form & University Location Cards */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            
            {/* Left: Contact Info & Desk */}
            <div className="lg:col-span-5 space-y-6">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
                  Direct Inquiries & Outreach
                </span>
                <h3 className="text-2xl font-bold font-academic text-slate-900 mt-1">
                  Connect with Abishek University
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  Have a specific inquiry about research collaborations, postgraduate fellowships, or student visas? Our admissions counsellors respond within 24 hours.
                </p>
              </div>

              <div className="space-y-4 text-xs sm:text-sm text-slate-700">
                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <MapPin className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900 font-semibold">Campus Address:</strong>
                    <span>Abishek University Main Campus, Innovation Corridor, Academic Heights, Metro City 94016</span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <Phone className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900 font-semibold">Telephone Helpline:</strong>
                    <span>{UNIVERSITY_INFO.helpline}</span>
                    <div className="text-xs text-slate-500 mt-0.5">Toll-free across North America & International Desk</div>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <Mail className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900 font-semibold">Official Email:</strong>
                    <span>{UNIVERSITY_INFO.admissionsEmail}</span>
                    <div className="text-xs text-slate-500 mt-0.5">General info: {UNIVERSITY_INFO.generalEmail}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <Clock className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900 font-semibold">Office Visiting Hours:</strong>
                    <span>Monday through Friday: 08:30 – 17:30 EST</span>
                    <div className="text-xs text-slate-500 mt-0.5">Saturday: 09:00 – 13:00 EST (Admissions Only)</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Working Contact Inquiry Form */}
            <div className="lg:col-span-7 bg-slate-50 p-6 sm:p-8 rounded-2xl border border-slate-200">
              {submitted ? (
                <div className="text-center py-12 space-y-4 animate-fadeIn">
                  <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h4 className="text-xl font-bold font-academic text-slate-900">
                    Thank You for Reaching Out!
                  </h4>
                  <p className="text-sm text-slate-600 max-w-md mx-auto">
                    Your inquiry has been routed to the Admissions & Student Affairs Office. An admissions counselor will respond to <strong className="text-slate-900">{form.email}</strong> shortly.
                  </p>
                  <button
                    onClick={handleReset}
                    className="mt-4 px-6 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors"
                  >
                    Send Another Inquiry
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <h4 className="text-lg font-bold font-academic text-slate-900 mb-2">
                    Send an Official Inquiry
                  </h4>

                  {error && (
                    <div className="p-3 rounded-xl bg-rose-50 text-rose-700 text-xs border border-rose-200 font-medium">
                      {error}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        placeholder="e.g. Marcus Aurelius"
                        className="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        value={form.email}
                        onChange={(e) => setForm({ ...form, email: e.target.value })}
                        placeholder="name@domain.com"
                        className="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Phone Number (Optional)
                      </label>
                      <input
                        type="tel"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        placeholder="+1 (555) 000-0000"
                        className="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Inquiry Category
                      </label>
                      <select
                        value={form.subject}
                        onChange={(e) => setForm({ ...form, subject: e.target.value })}
                        className="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                      >
                        <option value="General Admissions Inquiry">Undergraduate Admissions</option>
                        <option value="Postgraduate / MBA Programs">Postgraduate / MBA Programs</option>
                        <option value="Doctoral Fellowships">Doctoral Research Fellowships</option>
                        <option value="Scholarships & Aid">Scholarships & Financial Aid</option>
                        <option value="Campus Visit Booking">Campus Visit & Tour Booking</option>
                        <option value="International Student Visa">International Student Visa</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Your Message / Specific Question *
                    </label>
                    <textarea
                      rows={4}
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      placeholder="Please share details about your academic background or questions..."
                      className="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="inline-flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm shadow-md transition-all"
                  >
                    <span>Submit Inquiry</span>
                    <Send className="w-4 h-4 text-amber-400" />
                  </button>
                </form>
              )}
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
