import { useState, useRef, useEffect, FormEvent, ChangeEvent } from 'react';
import { 
  Check, 
  ArrowRight, 
  ArrowLeft, 
  UploadCloud, 
  FileText, 
  Trash2, 
  Sparkles, 
  AlertCircle, 
  Printer, 
  Download, 
  CheckCircle2, 
  Search, 
  Clock, 
  Calendar,
  X
} from 'lucide-react';
import { PROGRAMS, UNIVERSITY_INFO } from '../data';
import { AdmissionApplication } from '../types';

interface AdmissionsSectionProps {
  preselectedProgram?: string;
  preselectedDegree?: string;
  onApplicationCreated?: (app: AdmissionApplication) => void;
}

export default function AdmissionsSection({
  preselectedProgram,
  preselectedDegree,
  onApplicationCreated
}: AdmissionsSectionProps) {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Form State
  const [personal, setPersonal] = useState({
    fullName: '',
    email: '',
    phone: '',
    dob: '',
    gender: 'Prefer not to say',
    address: '',
    nationality: 'United States'
  });

  const [academic, setAcademic] = useState({
    previousInstitution: '',
    highestQualification: 'High School Diploma (10+2)',
    gpa: '',
    desiredDegree: preselectedDegree || 'Undergraduate',
    desiredMajor: preselectedProgram || PROGRAMS[0].title,
    graduationYear: '2026'
  });

  // Keep preselected updated
  useEffect(() => {
    if (preselectedProgram) {
      setAcademic(prev => ({ ...prev, desiredMajor: preselectedProgram }));
    }
    if (preselectedDegree) {
      setAcademic(prev => ({ ...prev, desiredDegree: preselectedDegree }));
    }
  }, [preselectedProgram, preselectedDegree]);

  // Documents
  const [transcripts, setTranscripts] = useState<string | null>(null);
  const [idProof, setIdProof] = useState<string | null>(null);
  const [sop, setSop] = useState<string | null>(null);

  // Submitted application modal state
  const [submittedApp, setSubmittedApp] = useState<AdmissionApplication | null>(null);

  // Check Status State
  const [trackIdInput, setTrackIdInput] = useState('');
  const [trackedApp, setTrackedApp] = useState<AdmissionApplication | null>(null);
  const [trackError, setTrackError] = useState('');

  // Sample quick fill for ease of testing
  const handleFillDemoData = () => {
    setPersonal({
      fullName: 'Aiden Alexander Vance',
      email: 'aiden.vance@example.com',
      phone: '+1 (555) 234-8901',
      dob: '2005-04-18',
      gender: 'Male',
      address: '742 Evergreen Terrace, Innovation Park, CA',
      nationality: 'United States'
    });
    setAcademic({
      previousInstitution: 'Apex Academy of Science & Math',
      highestQualification: 'High School Diploma (10+2)',
      gpa: '3.92',
      desiredDegree: 'Undergraduate',
      desiredMajor: 'B.Tech in Artificial Intelligence & Robotics',
      graduationYear: '2025'
    });
    setTranscripts('Apex_Academy_Final_Transcripts_2025.pdf');
    setIdProof('Passport_Bio_Page_AidenVance.pdf');
    setSop('Statement_of_Purpose_AI_Ethics_AU.docx');
    setErrors({});
  };

  // Step Validations
  const validateStep1 = () => {
    const errs: { [key: string]: string } = {};
    if (!personal.fullName.trim()) errs.fullName = 'Full Name is required.';
    if (!personal.email.trim()) {
      errs.email = 'Email address is required.';
    } else if (!/\S+@\S+\.\S+/.test(personal.email)) {
      errs.email = 'Please enter a valid email address.';
    }
    if (!personal.phone.trim()) errs.phone = 'Contact telephone number is required.';
    if (!personal.dob) errs.dob = 'Date of birth is required.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const validateStep2 = () => {
    const errs: { [key: string]: string } = {};
    if (!academic.previousInstitution.trim()) {
      errs.previousInstitution = 'Previous institution name is required.';
    }
    if (!academic.gpa.trim()) {
      errs.gpa = 'Grade Point Average (GPA) or Marks % is required.';
    }
    if (!academic.desiredMajor) {
      errs.desiredMajor = 'Please pick your desired major.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const validateStep3 = () => {
    const errs: { [key: string]: string } = {};
    if (!transcripts) {
      errs.transcripts = 'Academic transcript / mark sheet upload is required.';
    }
    if (!idProof) {
      errs.idProof = 'National ID, Passport, or student ID proof is required.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNext = () => {
    if (currentStep === 1) {
      if (validateStep1()) setCurrentStep(2);
    } else if (currentStep === 2) {
      if (validateStep2()) setCurrentStep(3);
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!validateStep3()) return;

    // Generate random Application ID
    const randomDigits = Math.floor(10000 + Math.random() * 90000);
    const newId = `AU-2026-${randomDigits}`;

    const newApp: AdmissionApplication = {
      id: newId,
      submittedAt: new Date().toLocaleString(),
      status: 'Pending Review',
      personal: { ...personal },
      academic: { ...academic },
      documents: {
        transcriptFile: transcripts || 'Transcripts.pdf',
        identityProofFile: idProof || 'ID_Proof.pdf',
        sopFile: sop || 'Statement_of_Purpose.pdf'
      }
    };

    // Save to localStorage
    try {
      const existing = localStorage.getItem('au_applications');
      const list: AdmissionApplication[] = existing ? JSON.parse(existing) : [];
      list.unshift(newApp);
      localStorage.setItem('au_applications', JSON.stringify(list));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }

    setSubmittedApp(newApp);
    if (onApplicationCreated) {
      onApplicationCreated(newApp);
    }
  };

  // Reset form to start a new application
  const handleResetForm = () => {
    setCurrentStep(1);
    setPersonal({
      fullName: '',
      email: '',
      phone: '',
      dob: '',
      gender: 'Prefer not to say',
      address: '',
      nationality: 'United States'
    });
    setAcademic({
      previousInstitution: '',
      highestQualification: 'High School Diploma (10+2)',
      gpa: '',
      desiredDegree: 'Undergraduate',
      desiredMajor: PROGRAMS[0].title,
      graduationYear: '2026'
    });
    setTranscripts(null);
    setIdProof(null);
    setSop(null);
    setSubmittedApp(null);
    setErrors({});
  };

  // Track status lookup
  const handleLookupStatus = () => {
    setTrackError('');
    setTrackedApp(null);
    if (!trackIdInput.trim()) {
      setTrackError('Please enter a valid Application ID (e.g., AU-2026-12345)');
      return;
    }

    try {
      const existing = localStorage.getItem('au_applications');
      const list: AdmissionApplication[] = existing ? JSON.parse(existing) : [];
      const found = list.find(a => a.id.trim().toUpperCase() === trackIdInput.trim().toUpperCase());

      if (found) {
        setTrackedApp(found);
      } else {
        setTrackError(`No application found for ID: ${trackIdInput.trim()}. Verify your application number or submit a new form.`);
      }
    } catch (e) {
      setTrackError('Unable to access stored applications.');
    }
  };

  // File Upload Handlers (simulated file picker)
  const handleSimulateUpload = (
    type: 'transcript' | 'idProof' | 'sop', 
    e: ChangeEvent<HTMLInputElement>
  ) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (type === 'transcript') setTranscripts(file.name);
      if (type === 'idProof') setIdProof(file.name);
      if (type === 'sop') setSop(file.name);
    }
  };

  return (
    <section id="admissions" className="py-20 bg-slate-900 text-white scroll-mt-16 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-400 bg-slate-800/80 px-3 py-1 rounded-full border border-amber-500/30">
            Admissions Cycle 2026-2027
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold font-academic text-white">
            Online Admission Application Portal
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Begin your journey at Abishek University. Submit your credentials through our encrypted multi-step portal. All applicants are automatically evaluated for merit scholarships.
          </p>
        </div>

        {/* Portal Grid: Left Form, Right Status Tracker / Help */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Main Multi-Step Form */}
          <div className="lg:col-span-8 bg-slate-950 rounded-3xl p-6 sm:p-10 border border-slate-800 shadow-2xl">
            
            {/* Form Top Utility */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-6 mb-8">
              <div>
                <h3 className="text-xl font-bold font-academic text-white">
                  Student Registration Dossier
                </h3>
                <p className="text-xs text-slate-400">
                  Step {currentStep} of 3: {
                    currentStep === 1 ? 'Personal Information' :
                    currentStep === 2 ? 'Academic Background' : 'Document Upload'
                  }
                </p>
              </div>

              <button
                type="button"
                onClick={handleFillDemoData}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 text-amber-400 hover:bg-slate-700 text-xs font-semibold border border-slate-700 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Fill Sample Demo Data</span>
              </button>
            </div>

            {/* Stepper Progress Bar */}
            <div className="mb-8">
              <div className="grid grid-cols-3 gap-2 sm:gap-4">
                {[
                  { step: 1, label: 'Personal Details' },
                  { step: 2, label: 'Academic Record' },
                  { step: 3, label: 'Documents & Submit' }
                ].map((s) => (
                  <div key={s.step} className="space-y-1.5">
                    <div className={`h-2 rounded-full transition-all ${
                      currentStep >= s.step ? 'bg-amber-500' : 'bg-slate-800'
                    }`}></div>
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        currentStep >= s.step ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {s.step}
                      </span>
                      <span className={`hidden sm:inline font-medium ${
                        currentStep === s.step ? 'text-amber-400' : 'text-slate-400'
                      }`}>
                        {s.label}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Step 1: Personal Information */}
            {currentStep === 1 && (
              <div className="space-y-6 animate-fadeIn">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Full Name (as on Passport/Certificates) *
                    </label>
                    <input
                      id="input-fullName"
                      type="text"
                      value={personal.fullName}
                      onChange={(e) => setPersonal({ ...personal, fullName: e.target.value })}
                      placeholder="e.g. Eleanor Vance"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    {errors.fullName && <p className="text-xs text-rose-400 mt-1">{errors.fullName}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Email Address *
                    </label>
                    <input
                      id="input-email"
                      type="email"
                      value={personal.email}
                      onChange={(e) => setPersonal({ ...personal, email: e.target.value })}
                      placeholder="student@example.com"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    {errors.email && <p className="text-xs text-rose-400 mt-1">{errors.email}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Phone Number (with country code) *
                    </label>
                    <input
                      id="input-phone"
                      type="tel"
                      value={personal.phone}
                      onChange={(e) => setPersonal({ ...personal, phone: e.target.value })}
                      placeholder="+1 (555) 019-2834"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    {errors.phone && <p className="text-xs text-rose-400 mt-1">{errors.phone}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Date of Birth *
                    </label>
                    <input
                      id="input-dob"
                      type="date"
                      value={personal.dob}
                      onChange={(e) => setPersonal({ ...personal, dob: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    {errors.dob && <p className="text-xs text-rose-400 mt-1">{errors.dob}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Gender Identity
                    </label>
                    <select
                      id="select-gender"
                      value={personal.gender}
                      onChange={(e) => setPersonal({ ...personal, gender: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="Female">Female</option>
                      <option value="Male">Male</option>
                      <option value="Non-Binary">Non-Binary</option>
                      <option value="Prefer not to say">Prefer not to say</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Nationality / Citizenship
                    </label>
                    <input
                      id="input-nationality"
                      type="text"
                      value={personal.nationality}
                      onChange={(e) => setPersonal({ ...personal, nationality: e.target.value })}
                      placeholder="e.g. United States, India, Canada..."
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Permanent Residential Address
                  </label>
                  <textarea
                    id="input-address"
                    rows={2}
                    value={personal.address}
                    onChange={(e) => setPersonal({ ...personal, address: e.target.value })}
                    placeholder="Street, City, State/Province, Postal Code, Country"
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div className="flex justify-end pt-4">
                  <button
                    type="button"
                    onClick={handleNext}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow-md transition-all"
                  >
                    <span>Proceed to Academic Background</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Academic Background */}
            {currentStep === 2 && (
              <div className="space-y-6 animate-fadeIn">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Previous School / College / University *
                    </label>
                    <input
                      id="input-previousInstitution"
                      type="text"
                      value={academic.previousInstitution}
                      onChange={(e) => setAcademic({ ...academic, previousInstitution: e.target.value })}
                      placeholder="e.g. Cambridge High School or University of Toronto"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    {errors.previousInstitution && <p className="text-xs text-rose-400 mt-1">{errors.previousInstitution}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Highest Completed Qualification
                    </label>
                    <select
                      id="select-highestQualification"
                      value={academic.highestQualification}
                      onChange={(e) => setAcademic({ ...academic, highestQualification: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="High School Diploma (10+2)">High School Diploma (10+2 / IB / A-Levels)</option>
                      <option value="Associate Degree">Associate Degree</option>
                      <option value="Bachelor's Degree">Bachelor's Degree</option>
                      <option value="Master's Degree">Master's Degree</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Cumulative GPA / Marks Percentage *
                    </label>
                    <input
                      id="input-gpa"
                      type="text"
                      value={academic.gpa}
                      onChange={(e) => setAcademic({ ...academic, gpa: e.target.value })}
                      placeholder="e.g. 3.85 / 4.0 or 88%"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    {errors.gpa && <p className="text-xs text-rose-400 mt-1">{errors.gpa}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Year of Graduation / Completion
                    </label>
                    <select
                      id="select-graduationYear"
                      value={academic.graduationYear}
                      onChange={(e) => setAcademic({ ...academic, graduationYear: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="2026">2026 (Upcoming)</option>
                      <option value="2025">2025</option>
                      <option value="2024">2024</option>
                      <option value="2023">2023</option>
                      <option value="2022">2022 or earlier</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Desired Degree Level *
                    </label>
                    <select
                      id="select-desiredDegree"
                      value={academic.desiredDegree}
                      onChange={(e) => {
                        const newDeg = e.target.value;
                        setAcademic({ ...academic, desiredDegree: newDeg });
                      }}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="Undergraduate">Undergraduate (B.Tech / B.Sc / B.A)</option>
                      <option value="Postgraduate">Postgraduate (MBA / M.S / M.Tech)</option>
                      <option value="Doctorate">Doctorate (Ph.D. / DBA)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Select Major / Program of Choice *
                    </label>
                    <select
                      id="select-desiredMajor"
                      value={academic.desiredMajor}
                      onChange={(e) => setAcademic({ ...academic, desiredMajor: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      {PROGRAMS.map((p) => (
                        <option key={p.id} value={p.title}>
                          {p.title} ({p.degree})
                        </option>
                      ))}
                    </select>
                    {errors.desiredMajor && <p className="text-xs text-rose-400 mt-1">{errors.desiredMajor}</p>}
                  </div>
                </div>

                <div className="flex justify-between pt-4">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(1)}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold transition-colors"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back to Personal</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleNext}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow-md transition-all"
                  >
                    <span>Proceed to Document Upload</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Document Upload Simulator */}
            {currentStep === 3 && (
              <form onSubmit={handleSubmit} className="space-y-6 animate-fadeIn">
                <div className="space-y-4">
                  <p className="text-xs text-slate-400">
                    Upload clear scanned PDFs or high-resolution images (max 10MB each). Real files can be selected or simulated.
                  </p>

                  {/* Document 1: Transcripts */}
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-200">
                        1. Academic Transcripts & Grade Sheets *
                      </span>
                      {transcripts ? (
                        <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Uploaded
                        </span>
                      ) : (
                        <span className="text-[11px] text-amber-400 font-semibold">Mandatory</span>
                      )}
                    </div>

                    {transcripts ? (
                      <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-700 text-xs">
                        <div className="flex items-center gap-2 text-slate-200">
                          <FileText className="w-4 h-4 text-amber-400" />
                          <span className="truncate max-w-xs">{transcripts}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setTranscripts(null)}
                          className="text-rose-400 hover:text-rose-300 p-1"
                          title="Remove file"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <label className="flex flex-col items-center justify-center p-5 border-2 border-dashed border-slate-700 hover:border-amber-500 rounded-xl cursor-pointer bg-slate-950/50 transition-colors">
                        <UploadCloud className="w-6 h-6 text-slate-400 mb-1" />
                        <span className="text-xs text-slate-300 font-medium">
                          Click to browse or drop transcript PDF
                        </span>
                        <span className="text-[10px] text-slate-500 mt-0.5">PDF, PNG, JPG up to 10MB</span>
                        <input
                          type="file"
                          accept=".pdf,.png,.jpg,.jpeg"
                          className="hidden"
                          onChange={(e) => handleSimulateUpload('transcript', e)}
                        />
                      </label>
                    )}
                    {errors.transcripts && <p className="text-xs text-rose-400">{errors.transcripts}</p>}
                  </div>

                  {/* Document 2: ID Proof */}
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-200">
                        2. Government ID Proof / Passport Bio-Page *
                      </span>
                      {idProof ? (
                        <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Uploaded
                        </span>
                      ) : (
                        <span className="text-[11px] text-amber-400 font-semibold">Mandatory</span>
                      )}
                    </div>

                    {idProof ? (
                      <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-700 text-xs">
                        <div className="flex items-center gap-2 text-slate-200">
                          <FileText className="w-4 h-4 text-blue-400" />
                          <span className="truncate max-w-xs">{idProof}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setIdProof(null)}
                          className="text-rose-400 hover:text-rose-300 p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <label className="flex flex-col items-center justify-center p-5 border-2 border-dashed border-slate-700 hover:border-amber-500 rounded-xl cursor-pointer bg-slate-950/50 transition-colors">
                        <UploadCloud className="w-6 h-6 text-slate-400 mb-1" />
                        <span className="text-xs text-slate-300 font-medium">
                          Click to browse or drop ID scan
                        </span>
                        <span className="text-[10px] text-slate-500 mt-0.5">Government ID, Passport, Driver's License</span>
                        <input
                          type="file"
                          accept=".pdf,.png,.jpg,.jpeg"
                          className="hidden"
                          onChange={(e) => handleSimulateUpload('idProof', e)}
                        />
                      </label>
                    )}
                    {errors.idProof && <p className="text-xs text-rose-400">{errors.idProof}</p>}
                  </div>

                  {/* Document 3: Statement of Purpose (Optional) */}
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-200">
                        3. Statement of Purpose (SOP) / Essay (Recommended)
                      </span>
                      {sop ? (
                        <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Uploaded
                        </span>
                      ) : (
                        <span className="text-[11px] text-slate-400 font-normal">Optional</span>
                      )}
                    </div>

                    {sop ? (
                      <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-700 text-xs">
                        <div className="flex items-center gap-2 text-slate-200">
                          <FileText className="w-4 h-4 text-purple-400" />
                          <span className="truncate max-w-xs">{sop}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setSop(null)}
                          className="text-rose-400 hover:text-rose-300 p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <label className="flex flex-col items-center justify-center p-5 border-2 border-dashed border-slate-700 hover:border-amber-500 rounded-xl cursor-pointer bg-slate-950/50 transition-colors">
                        <UploadCloud className="w-6 h-6 text-slate-400 mb-1" />
                        <span className="text-xs text-slate-300 font-medium">
                          Click to browse or drop Statement of Purpose
                        </span>
                        <input
                          type="file"
                          accept=".pdf,.docx,.txt"
                          className="hidden"
                          onChange={(e) => handleSimulateUpload('sop', e)}
                        />
                      </label>
                    )}
                  </div>
                </div>

                <div className="flex justify-between pt-4">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(2)}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold transition-colors"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back to Academic</span>
                  </button>

                  <button
                    id="submit-admission-form-btn"
                    type="submit"
                    className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow-xl transition-all"
                  >
                    <span>Submit Complete Application</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

          </div>

          {/* Right Column: Check Application Status & Direct Admissions Support */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Quick Status Lookup Card */}
            <div className="bg-slate-950 rounded-3xl p-6 border border-slate-800 shadow-xl space-y-4">
              <div className="flex items-center gap-2.5 text-amber-400">
                <Search className="w-5 h-5" />
                <h3 className="text-lg font-bold font-academic text-white">
                  Check Application Status
                </h3>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Already submitted an application? Enter your unique Application ID below to view verification updates in real time.
              </p>

              <div className="space-y-2">
                <input
                  id="status-lookup-input"
                  type="text"
                  value={trackIdInput}
                  onChange={(e) => setTrackIdInput(e.target.value)}
                  placeholder="e.g. AU-2026-48291"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs uppercase tracking-wider focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                {trackError && <p className="text-xs text-rose-400">{trackError}</p>}
                
                <button
                  id="status-lookup-btn"
                  type="button"
                  onClick={handleLookupStatus}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold transition-colors border border-slate-700"
                >
                  Verify Application ID
                </button>
              </div>

              {/* Status Lookup Result Panel */}
              {trackedApp && (
                <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/40 space-y-3 animate-fadeIn">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="text-[11px] font-bold text-amber-400">
                      {trackedApp.id}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {trackedApp.status}
                    </span>
                  </div>

                  <div className="text-xs space-y-1">
                    <div className="text-white font-semibold">{trackedApp.personal.fullName}</div>
                    <div className="text-slate-400">{trackedApp.academic.desiredMajor}</div>
                    <div className="text-[11px] text-slate-500">Submitted: {trackedApp.submittedAt}</div>
                  </div>

                  {/* Live Progress Milestones */}
                  <div className="pt-2 border-t border-slate-800 space-y-2 text-[11px]">
                    <div className="flex items-center gap-2 text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Form Dossier Submitted</span>
                    </div>
                    <div className="flex items-center gap-2 text-amber-400">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Academic Committee Verification</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-500">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Faculty Interview Scheduling</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Admission Counseling Desk */}
            <div className="bg-gradient-to-br from-amber-500/10 to-transparent p-6 rounded-3xl border border-amber-500/30 space-y-3">
              <h4 className="text-base font-bold font-academic text-amber-400">
                Need Guidance with your Application?
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Our admissions officers hold daily drop-in virtual office hours. Get help with transcript evaluations, major selections, and visa eligibility.
              </p>
              <div className="text-xs text-slate-200 space-y-1 pt-1">
                <div><strong>Helpline:</strong> {UNIVERSITY_INFO.helpline}</div>
                <div><strong>Email:</strong> {UNIVERSITY_INFO.admissionsEmail}</div>
                <div><strong>Hours:</strong> Mon - Sat, 08:00 - 18:00 EST</div>
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* Submitted Application Confirmation Modal */}
      {submittedApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-white text-slate-900 rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative space-y-6 max-h-[90vh] overflow-y-auto">
            
            {/* Header with University Crest & ID */}
            <div className="flex items-start justify-between border-b border-slate-200 pb-4">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-widest text-amber-600 bg-amber-50 px-2.5 py-0.5 rounded">
                  Official Acknowledgment Receipt
                </span>
                <h3 className="text-2xl font-bold font-academic text-slate-900 mt-1">
                  Application Successfully Submitted
                </h3>
              </div>
              <button 
                onClick={handleResetForm}
                className="text-slate-400 hover:text-slate-700 p-1"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Application ID Highlight Box */}
            <div className="bg-slate-900 text-white p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[11px] text-slate-400 uppercase tracking-wider block">
                  Your Official Application ID
                </span>
                <span className="text-2xl font-black font-academic text-amber-400 tracking-wider">
                  {submittedApp.id}
                </span>
              </div>
              <div className="text-left sm:text-right">
                <span className="text-[10px] px-2.5 py-1 rounded-full font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 inline-block">
                  Status: {submittedApp.status}
                </span>
                <span className="text-[11px] text-slate-400 block mt-1">
                  {submittedApp.submittedAt}
                </span>
              </div>
            </div>

            {/* Applicant Summary */}
            <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <div>
                <span className="text-slate-500 block">Applicant Name</span>
                <span className="font-bold text-slate-900">{submittedApp.personal.fullName}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Primary Email</span>
                <span className="font-bold text-slate-900">{submittedApp.personal.email}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Desired Program</span>
                <span className="font-bold text-slate-900">{submittedApp.academic.desiredMajor}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Degree Level</span>
                <span className="font-bold text-slate-900">{submittedApp.academic.desiredDegree}</span>
              </div>
              <div>
                <span className="text-slate-500 block">GPA / Score</span>
                <span className="font-bold text-slate-900">{submittedApp.academic.gpa}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Institution</span>
                <span className="font-bold text-slate-900">{submittedApp.academic.previousInstitution}</span>
              </div>
            </div>

            {/* Next Steps Notification */}
            <div className="text-xs text-slate-600 bg-amber-50 p-3.5 rounded-xl border border-amber-200 space-y-1">
              <strong className="text-amber-900">What happens next?</strong>
              <p>
                Our admissions committee will verify your academic transcripts within 3-5 business days. 
                Please save your Application ID (<strong className="text-slate-950">{submittedApp.id}</strong>) to track updates or download this official confirmation receipt.
              </p>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>Print Official Receipt</span>
              </button>

              <button
                type="button"
                onClick={handleResetForm}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-all"
              >
                <span>Done & New Application</span>
                <Check className="w-4 h-4" />
              </button>
            </div>

          </div>
        </div>
      )}
    </section>
  );
}
