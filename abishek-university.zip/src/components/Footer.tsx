import { GraduationCap, ArrowUp, ShieldCheck, Award, Globe, Heart } from 'lucide-react';
import { UNIVERSITY_INFO } from '../data';

interface FooterProps {
  onNavigateTo: (sectionId: string) => void;
}

export default function Footer({ onNavigateTo }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-800 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Main Footer Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800/80">
          
          {/* Brand & Crest */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 shadow-md">
                <GraduationCap className="w-6 h-6 text-slate-950" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xl font-bold tracking-tight text-white font-crest">
                    ABISHEK
                  </span>
                  <span className="text-xl font-light tracking-wide text-amber-400">
                    UNIVERSITY
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 font-medium tracking-wider uppercase">
                  {UNIVERSITY_INFO.motto}
                </p>
              </div>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              A premier collegiate institution dedicated to research rigor, quantum technologies, sustainable living, and principled global leadership since 1985.
            </p>

            <div className="space-y-1 text-slate-300 text-[11px]">
              <div><strong>Accreditation:</strong> {UNIVERSITY_INFO.accreditation}</div>
              <div><strong>Admissions Desk:</strong> {UNIVERSITY_INFO.admissionsEmail}</div>
              <div><strong>Toll-Free Helpline:</strong> {UNIVERSITY_INFO.helpline}</div>
            </div>
          </div>

          {/* Column 2: Navigation */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white font-academic">
              Quick Links
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button onClick={() => onNavigateTo('home')} className="hover:text-amber-400 transition-colors">
                  Front Page & Ticker
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateTo('about')} className="hover:text-amber-400 transition-colors">
                  Founder's Vision & History
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateTo('academics')} className="hover:text-amber-400 transition-colors">
                  Program Finder & Syllabus
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateTo('campus')} className="hover:text-amber-400 transition-colors">
                  Campus Life & Hostels
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateTo('admissions')} className="hover:text-amber-400 transition-colors">
                  Online Admission Portal
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateTo('calculator')} className="hover:text-amber-400 transition-colors">
                  Tuition Fee Calculator
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateTo('tour')} className="hover:text-amber-400 transition-colors">
                  Virtual Campus Tour
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Academic Faculties */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white font-academic">
              Faculties & Centers
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>School of Artificial Intelligence</li>
              <li>Faculty of Engineering & Tech</li>
              <li>School of Global Business & MBA</li>
              <li>Center for Precision Medicine</li>
              <li>College of Humanities & Arts</li>
              <li>Quantum Computing Research Hub</li>
              <li>Center for Sustainable Green Energy</li>
            </ul>
          </div>

          {/* Column 4: Student Life & Support */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white font-academic">
              Campus & Aid
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>Chancellor's Merit Scholarship</li>
              <li>Sir Arthur Knowledge Hub</li>
              <li>Olympic Sports & Health Complex</li>
              <li>Eco-Village Student Hostels</li>
              <li>International Scholar Services</li>
              <li>Career Placement Directorate</li>
              <li>Emergency Campus Security</li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Back to Top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-400">
          <div className="flex items-center gap-2">
            <span>© 2026 Abishek University. All rights reserved.</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={scrollToTop}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-amber-400 border border-slate-800 transition-colors"
            >
              <span>Back to top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
}
