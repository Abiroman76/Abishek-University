import { useState, useMemo } from 'react';
import { 
  Calculator, 
  DollarSign, 
  Home, 
  Utensils, 
  Award, 
  Globe2, 
  ArrowRight, 
  HelpCircle 
} from 'lucide-react';
import { PROGRAMS } from '../data';

interface FeeCalculatorProps {
  onApplyWithEstimates: (programTitle: string) => void;
}

export default function FeeCalculator({ onApplyWithEstimates }: FeeCalculatorProps) {
  const [selectedProgramId, setSelectedProgramId] = useState(PROGRAMS[0].id);
  const [residency, setResidency] = useState<'domestic' | 'international'>('domestic');
  const [housingOption, setHousingOption] = useState<'none' | 'standard' | 'deluxe'>('standard');
  const [mealPlan, setMealPlan] = useState<'none' | 'standard' | 'unlimited'>('standard');
  const [scholarshipPercent, setScholarshipPercent] = useState<number>(0);

  const selectedProgram = PROGRAMS.find(p => p.id === selectedProgramId) || PROGRAMS[0];

  // Calculation Logic
  const calculations = useMemo(() => {
    let baseTuition = selectedProgram.tuitionPerSemester;
    if (residency === 'international') {
      baseTuition = Math.round(baseTuition * 1.22); // International support surcharge
    }

    const techAndLabFee = 450;

    let housingFee = 0;
    if (housingOption === 'standard') housingFee = 1850;
    if (housingOption === 'deluxe') housingFee = 2650;

    let mealFee = 0;
    if (mealPlan === 'standard') mealFee = 980;
    if (mealPlan === 'unlimited') mealFee = 1450;

    const grossTuition = baseTuition;
    const scholarshipDeduction = Math.round((grossTuition * scholarshipPercent) / 100);
    const netTuition = grossTuition - scholarshipDeduction;

    const totalSemesterEstimate = netTuition + techAndLabFee + housingFee + mealFee;
    const estimatedAnnualCost = totalSemesterEstimate * 2;

    return {
      baseTuition,
      scholarshipDeduction,
      netTuition,
      techAndLabFee,
      housingFee,
      mealFee,
      totalSemesterEstimate,
      estimatedAnnualCost
    };
  }, [selectedProgram, residency, housingOption, mealPlan, scholarshipPercent]);

  return (
    <section id="calculator" className="py-20 bg-white border-b border-slate-200 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-600 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
            Transparent Academic Investment
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold font-academic text-slate-900">
            Interactive Tuition Fee & Cost Calculator
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Estimate your semester expenditure in seconds. Transparently configure your chosen degree program, residential accommodations, dining plans, and projected scholarship waivers.
          </p>
        </div>

        {/* Calculator Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Controls Form Panel */}
          <div className="lg:col-span-7 bg-slate-50 p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
            
            {/* 1. Academic Program */}
            <div className="space-y-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                1. Select Academic Program & Degree
              </label>
              <select
                id="calc-program-select"
                value={selectedProgramId}
                onChange={(e) => setSelectedProgramId(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-white border border-slate-300 text-slate-900 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-xs"
              >
                {PROGRAMS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.title} ({p.degree} · ${p.tuitionPerSemester.toLocaleString()}/sem)
                  </option>
                ))}
              </select>
            </div>

            {/* 2. Residency Status */}
            <div className="space-y-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                2. Student Residency Status
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setResidency('domestic')}
                  className={`py-3 px-4 rounded-xl text-xs font-semibold border transition-all flex items-center justify-center gap-2 ${
                    residency === 'domestic'
                      ? 'bg-slate-900 text-amber-400 border-slate-900 shadow-sm'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Award className="w-4 h-4" />
                  <span>Domestic Resident</span>
                </button>
                <button
                  type="button"
                  onClick={() => setResidency('international')}
                  className={`py-3 px-4 rounded-xl text-xs font-semibold border transition-all flex items-center justify-center gap-2 ${
                    residency === 'international'
                      ? 'bg-slate-900 text-amber-400 border-slate-900 shadow-sm'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Globe2 className="w-4 h-4" />
                  <span>International Scholar</span>
                </button>
              </div>
            </div>

            {/* 3. Housing & Residence Option */}
            <div className="space-y-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                3. Campus Living & Accommodation
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { id: 'none', label: 'Day Scholar / Off-Campus', cost: '$0 / sem' },
                  { id: 'standard', label: 'Eco-Village Double Suite', cost: '+$1,850 / sem' },
                  { id: 'deluxe', label: 'Deluxe Single Studio', cost: '+$2,650 / sem' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setHousingOption(item.id as any)}
                    className={`p-3 rounded-xl text-left border transition-all ${
                      housingOption === item.id
                        ? 'bg-amber-500/10 border-amber-500 text-slate-900 font-bold'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <div className="text-xs font-semibold">{item.label}</div>
                    <div className="text-[11px] text-amber-700 font-medium mt-0.5">{item.cost}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* 4. Dining Plan */}
            <div className="space-y-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                4. Campus Dining & Meal Plan
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { id: 'none', label: 'Self-Catering / None', cost: '$0 / sem' },
                  { id: 'standard', label: '10-Meal Weekly Flex', cost: '+$980 / sem' },
                  { id: 'unlimited', label: 'All-Access Unlimited', cost: '+$1,450 / sem' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setMealPlan(item.id as any)}
                    className={`p-3 rounded-xl text-left border transition-all ${
                      mealPlan === item.id
                        ? 'bg-amber-500/10 border-amber-500 text-slate-900 font-bold'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <div className="text-xs font-semibold">{item.label}</div>
                    <div className="text-[11px] text-amber-700 font-medium mt-0.5">{item.cost}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* 5. Projected Merit Scholarship Slider */}
            <div className="space-y-3 pt-2 border-t border-slate-200">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5 text-amber-600" />
                  Estimated Merit Scholarship Waiver
                </label>
                <span className="text-sm font-extrabold text-amber-700 bg-amber-100 px-2.5 py-0.5 rounded-full">
                  {scholarshipPercent}% Tuition Relief
                </span>
              </div>
              <input
                id="calc-scholarship-slider"
                type="range"
                min="0"
                max="100"
                step="5"
                value={scholarshipPercent}
                onChange={(e) => setScholarshipPercent(Number(e.target.value))}
                className="w-full accent-amber-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>0% (Standard)</span>
                <span>25% Dean's Award</span>
                <span>50% Honors</span>
                <span>100% Chancellor's Fellow</span>
              </div>
            </div>

          </div>

          {/* Real-time Itemized Output Summary Panel */}
          <div className="lg:col-span-5 bg-slate-900 text-white p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-xl space-y-6 sticky top-28">
            
            <div className="border-b border-slate-800 pb-4">
              <span className="text-[11px] font-bold uppercase tracking-widest text-amber-400">
                Semester Financial Ledger
              </span>
              <h3 className="text-2xl font-bold font-academic text-white mt-0.5">
                Estimated Investment
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Calculated for {selectedProgram.title} ({residency === 'domestic' ? 'Domestic' : 'International'})
              </p>
            </div>

            {/* Itemized Line Items */}
            <div className="space-y-3 text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Base Academic Tuition:</span>
                <span className="font-semibold text-white">
                  ${calculations.baseTuition.toLocaleString()}
                </span>
              </div>

              {calculations.scholarshipDeduction > 0 && (
                <div className="flex justify-between text-emerald-400 font-semibold bg-emerald-950/40 px-2.5 py-1.5 rounded-lg border border-emerald-800/40">
                  <span>Merit Scholarship ({scholarshipPercent}%):</span>
                  <span>-${calculations.scholarshipDeduction.toLocaleString()}</span>
                </div>
              )}

              <div className="flex justify-between text-slate-300">
                <span>Laboratory, Computing & Library Fee:</span>
                <span className="font-semibold text-white">
                  ${calculations.techAndLabFee.toLocaleString()}
                </span>
              </div>

              <div className="flex justify-between text-slate-300">
                <span>Campus Housing ({housingOption}):</span>
                <span className="font-semibold text-white">
                  ${calculations.housingFee.toLocaleString()}
                </span>
              </div>

              <div className="flex justify-between text-slate-300">
                <span>Dining & Meal Services ({mealPlan}):</span>
                <span className="font-semibold text-white">
                  ${calculations.mealFee.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Grand Total Box */}
            <div className="pt-4 border-t border-slate-800 bg-slate-950/70 p-4 rounded-2xl border border-amber-500/20 space-y-1">
              <div className="flex items-baseline justify-between">
                <span className="text-xs uppercase font-bold text-slate-400 tracking-wider">
                  Total Per Semester:
                </span>
                <span className="text-3xl font-black font-academic text-amber-400">
                  ${calculations.totalSemesterEstimate.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-[11px] text-slate-400 pt-1">
                <span>Projected Academic Year (2 Semesters):</span>
                <span className="text-slate-200 font-semibold">
                  ${calculations.estimatedAnnualCost.toLocaleString()}
                </span>
              </div>
            </div>

            {/* CTA */}
            <button
              type="button"
              onClick={() => onApplyWithEstimates(selectedProgram.title)}
              className="w-full py-3.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
            >
              <span>Apply for {selectedProgram.shortDesc.slice(0, 20)}...</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="text-[11px] text-slate-500 leading-tight text-center">
              * Figures are indicative estimates for planning purposes. Fixed fees are confirmed upon official admission verification.
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
