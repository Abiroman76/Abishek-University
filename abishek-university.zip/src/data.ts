import { 
  AcademicProgram, 
  Announcement, 
  Milestone, 
  Leader, 
  Facility, 
  StudentTestimonial, 
  CampusHotspot, 
  FAQItem 
} from './types';

export const UNIVERSITY_INFO = {
  name: "Abishek University",
  shortName: "AU",
  motto: "Empowering Minds, Shaping the Future",
  founded: "1985",
  location: "Metro Innovation Corridor, Academic Heights",
  accreditation: "NAAC A++ Accredited | QS Top 100 World University Alliance",
  admissionCycle: "Fall 2026 - 2027 Admissions Open",
  helpline: "+1 (800) 542-ABISHEK",
  admissionsEmail: "admissions@abishek.edu",
  generalEmail: "info@abishek.edu"
};

export const QUICK_STATS = [
  { label: "Global Alumni Network", value: "50,000+", change: "Across 74 Countries" },
  { label: "Accredited Programs", value: "150+", change: "UG, PG & Doctoral" },
  { label: "Career Placement Rate", value: "98.4%", change: "Fortune 500 Partners" },
  { label: "National Innovation Rank", value: "#1 Campus", change: "AI & Green Tech 2025" },
  { label: "Sponsored Research", value: "$62M+", change: "Annual Innovation Grants" },
];

export const ANNOUNCEMENTS: Announcement[] = [
  {
    id: "ann-1",
    title: "Chancellor's Merit Scholarship 2026: 100% Tuition Waivers Open for Applications",
    date: "Sep 12, 2026",
    category: "Admissions",
    summary: "High-achieving applicants with GPA ≥ 3.8 are invited to submit scholarship dossiers before October 15.",
    urgent: true
  },
  {
    id: "ann-2",
    title: "Abishek Quantum & Neural Computing Center Inks Global Tech Partnership",
    date: "Sep 08, 2026",
    category: "Research",
    summary: "A joint $14M grant will establish next-gen supercomputing nodes for student-led AI discovery.",
    urgent: false
  },
  {
    id: "ann-3",
    title: "Mid-Term Examination Schedule Released for Fall Semester 2026",
    date: "Sep 05, 2026",
    category: "Academic",
    summary: "Students can access their personalized test timetables and hall tickets via the Student ERP portal.",
    urgent: false
  },
  {
    id: "ann-4",
    title: "International Sustainable Energy Symposium to Host Nobel Laureates",
    date: "Aug 29, 2026",
    category: "Events",
    summary: "Three-day global conference featuring keynote sessions, pitch competitions, and green tech demonstrations.",
    urgent: false
  },
  {
    id: "ann-5",
    title: "Early Action Admissions Deadline Approaching for International Scholars",
    date: "Aug 22, 2026",
    category: "Admissions",
    summary: "International visa assistance desk is now hosting daily 1-on-1 virtual counseling webinars.",
    urgent: true
  }
];

export const PROGRAMS: AcademicProgram[] = [
  {
    id: "prog-1",
    title: "B.Tech in Artificial Intelligence & Robotics",
    degree: "Undergraduate",
    field: "Artificial Intelligence",
    duration: "4 Years (8 Semesters)",
    eligibility: "High School Diploma / 10+2 with Physics, Mathematics & 75%+ Aggregate",
    credits: 160,
    tuitionPerSemester: 6200,
    shortDesc: "Pioneering engineering program blending deep learning architectures, humanoid kinematics, neuromorphic computing, and ethical AI systems.",
    careerOutlook: "AI Research Scientist, Robotics System Architect, Autonomous Vehicle Engineer",
    badge: "Top Rated",
    iconName: "Cpu",
    syllabus: [
      {
        semester: 1,
        title: "Foundations of Neural Math & Programming",
        courses: ["Calculus & Linear Algebra for AI", "Advanced Python & C++ Mastery", "Digital Logic & Computer Organization", "Algorithmic Thinking"]
      },
      {
        semester: 2,
        title: "Data Systems & Machine Learning Core",
        courses: ["Probability & Stochastic Modeling", "Data Structures & High-Performance Algorithms", "Supervised & Unsupervised Learning", "Microcontrollers Lab"]
      },
      {
        semester: 3,
        title: "Deep Architectures & Perception",
        courses: ["Computer Vision with PyTorch", "Natural Language Processing & Transformers", "Kinematics & Control Dynamics", "Database Systems"]
      },
      {
        semester: 4,
        title: "Robotics & Autonomous Deployment",
        courses: ["Sensor Fusion & SLAM", "Reinforcement Learning & Game Theory", "Embedded Edge AI Systems", "Capstone Design Project I"]
      }
    ]
  },
  {
    id: "prog-2",
    title: "B.Sc in Computer Science & Cloud Systems",
    degree: "Undergraduate",
    field: "Engineering & Tech",
    duration: "4 Years (8 Semesters)",
    eligibility: "High School completion with Mathematics & Science (Min. 70%)",
    credits: 155,
    tuitionPerSemester: 5800,
    shortDesc: "Industry-aligned software engineering curriculum focusing on scalable distributed networks, cyber defense, and containerized microservices.",
    careerOutlook: "Full-Stack Software Engineer, Cloud Solutions Architect, DevOps Specialist",
    badge: "Flagship",
    iconName: "Code2",
    syllabus: [
      {
        semester: 1,
        title: "Core Computing Principles",
        courses: ["Introduction to Software Craftsmanship", "Discrete Mathematics", "Operating System Kernels", "Web Architectures"]
      },
      {
        semester: 2,
        title: "Distributed Systems & Networking",
        courses: ["Computer Networks & Protocols", "Object-Oriented Design Patterns", "Database Engine Internals", "Cloud Native Foundations"]
      },
      {
        semester: 3,
        title: "Security & Cloud Scale",
        courses: ["Distributed Consensus Systems", "Cryptography & Secure Coding", "Container Orchestration with K8s", "Software Testing QA"]
      }
    ]
  },
  {
    id: "prog-3",
    title: "Master of Business Administration (Global MBA)",
    degree: "Postgraduate",
    field: "Business",
    duration: "2 Years (4 Semesters)",
    eligibility: "Bachelor's Degree in any discipline with min. 60% + Valid GMAT/AU-MAT score",
    credits: 90,
    tuitionPerSemester: 7500,
    shortDesc: "Executive-grade management immersion in venture capital, financial technology, sustainable leadership, and international trade operations.",
    careerOutlook: "Management Consultant, Investment Banker, Product Strategy Director, Startup Founder",
    badge: "AACSB Mapped",
    iconName: "Briefcase",
    syllabus: [
      {
        semester: 1,
        title: "Strategic Fundamentals & Analytics",
        courses: ["Financial Accounting for Executives", "Managerial Economics & Strategy", "Data Analytics for Business Decisions", "Organizational Behavior"]
      },
      {
        semester: 2,
        title: "Market Dynamics & Operations",
        courses: ["Corporate Finance & Valuation", "Omnichannel Marketing Strategy", "Global Supply Chain Optimization", "Design Thinking Lab"]
      },
      {
        semester: 3,
        title: "Specializations & Venture Lab",
        courses: ["Mergers & Acquisitions", "FinTech & Blockchain Economics", "Venture Capital Studio", "Consulting Practicum"]
      }
    ]
  },
  {
    id: "prog-4",
    title: "M.S. in Biotechnology & Precision Medicine",
    degree: "Postgraduate",
    field: "Medicine",
    duration: "2 Years (4 Semesters)",
    eligibility: "B.Sc/B.Tech in Life Sciences, MBBS, Pharmacy, or Bio-Engineering with 65%+",
    credits: 84,
    tuitionPerSemester: 6800,
    shortDesc: "Translational medical research harnessing CRISPR genomic editing, clinical bioinformatics, immunotherapy, and computational drug discovery.",
    careerOutlook: "Clinical Research Scientist, Bio-pharmacologist, Genomic Analyst",
    badge: "NIH Collaborating",
    iconName: "Activity",
    syllabus: [
      {
        semester: 1,
        title: "Molecular Genetics & Cellular Dynamics",
        courses: ["Advanced Molecular Biology", "Structural Bioinformatics", "Bio-statistics & Clinical Trial Design", "Bio-Nanotechnology"]
      },
      {
        semester: 2,
        title: "Therapeutics & Genomic Editing",
        courses: ["Gene Therapy & CRISPR Technology", "Immunology & Vaccine Formulation", "Pharmacogenomics", "Regulatory Affairs & Bioethics"]
      }
    ]
  },
  {
    id: "prog-5",
    title: "Ph.D. in Autonomous Systems & Cognitive Science",
    degree: "Doctorate",
    field: "Artificial Intelligence",
    duration: "3-5 Years",
    eligibility: "Master's Degree in Computer Science, AI, or allied disciplines with Research Thesis",
    credits: 120,
    tuitionPerSemester: 4500,
    shortDesc: "Fellowship-funded doctoral research investigating human-robot interaction, neuromorphic computing, neural interfaces, and autonomous agent safety.",
    careerOutlook: "University Professor, Principal Scientist, R&D Lab Director",
    badge: "Full Fellowship Available",
    iconName: "Atom",
    syllabus: [
      {
        semester: 1,
        title: "Doctoral Research Methodologies",
        courses: ["Advanced Research Ethics & Publication", "High-Dimensional Statistical Inference", "Seminar in Frontier Cognitive Architectures"]
      },
      {
        semester: 2,
        title: "Comprehensive Proposal & Field Work",
        courses: ["Doctoral Candidacy Defense", "Specialized Dissertation Investigation I & II"]
      }
    ]
  },
  {
    id: "prog-6",
    title: "B.A. in Digital Media & Global Humanities",
    degree: "Undergraduate",
    field: "Humanities",
    duration: "3 Years (6 Semesters)",
    eligibility: "High School completion in any stream with English proficiency (Min. 60%)",
    credits: 120,
    tuitionPerSemester: 4800,
    shortDesc: "Interdisciplinary exploration blending philosophical inquiry, visual storytelling, digital journalism, and cultural anthropology in a hyper-connected age.",
    careerOutlook: "Creative Director, Digital Journalist, Policy Analyst, Communications Head",
    badge: "Creative Arts",
    iconName: "BookOpen",
    syllabus: [
      {
        semester: 1,
        title: "Cultural Narratives & Critical Thought",
        courses: ["History of Ideas & World Philosophy", "Media Rhetoric & Digital Literacy", "Creative Non-Fiction Writing", "Visual Semiotics"]
      },
      {
        semester: 2,
        title: "Interactive Storytelling & Ethics",
        courses: ["Documentary Filmmaking", "Digital Ethnography", "Global Politics & Social Media", "Podcast & Sound Design Studio"]
      }
    ]
  },
  {
    id: "prog-7",
    title: "M.Tech in Cyber Physical Systems & IoT",
    degree: "Postgraduate",
    field: "Engineering & Tech",
    duration: "2 Years (4 Semesters)",
    eligibility: "B.E./B.Tech in ECE, EEE, CS, or IT with min 60%",
    credits: 80,
    tuitionPerSemester: 5900,
    shortDesc: "Advanced training in smart grids, industrial automation, hardware security, SCADA defense, and resilient smart city infrastructure.",
    careerOutlook: "IoT Solutions Architect, Embedded Security Specialist, Automation Consultant",
    iconName: "ShieldCheck",
    syllabus: [
      {
        semester: 1,
        title: "Hardware Architecture & Sensor Networks",
        courses: ["Industrial IoT Protocols", "Real-Time Embedded Operating Systems", "Hardware Cryptography", "Wireless Sensor Networks"]
      },
      {
        semester: 2,
        title: "Autonomous Control & Industrial Defense",
        courses: ["Cyber-Physical Security Auditing", "Smart Grid Architectures", "Digital Twin Engineering", "Industrial Practicum"]
      }
    ]
  },
  {
    id: "prog-8",
    title: "Doctor of Business Administration (DBA)",
    degree: "Doctorate",
    field: "Business",
    duration: "3 Years",
    eligibility: "MBA/Master's degree with 5+ years of managerial or entrepreneurial experience",
    credits: 90,
    tuitionPerSemester: 6500,
    shortDesc: "Applied executive doctorate designed for C-suite leaders addressing transformative business models, geopolitical risk, and corporate longevity.",
    careerOutlook: "Executive Chairman, Chief Strategy Officer, Think-Tank Senior Fellow",
    badge: "Executive Track",
    iconName: "TrendingUp",
    syllabus: [
      {
        semester: 1,
        title: "Applied Organizational Theory",
        courses: ["Qualitative & Quantitative Enterprise Research", "Corporate Governance & Board Dynamics", "Global Economic Policy"]
      },
      {
        semester: 2,
        title: "Applied Dissertation Residency",
        courses: ["Executive Research Defense", "Case Method Field Publication"]
      }
    ]
  }
];

export const MILESTONES: Milestone[] = [
  {
    year: "1985",
    title: "Founding by Chancellor Abishek",
    description: "Inaugurated as an independent Institute of Technology with an initial charter to blend academic rigor with ethical stewardship.",
    icon: "GraduationCap"
  },
  {
    year: "1997",
    title: "Establishment of Advanced Research Wing",
    description: "Commissioned the Central Research Laboratories and expanded graduate programs into Biomedical and Applied Mathematics.",
    icon: "FlaskConical"
  },
  {
    year: "2010",
    title: "Attainment of Full Autonomous University Status",
    description: "Accredited with national highest tier A++ honor, expanding into a 180-acre smart eco-campus with 40 international partner universities.",
    icon: "Award"
  },
  {
    year: "2018",
    title: "Launch of the Quantum & AI Innovation Hub",
    description: "Endowed with $40M dedicated fund, inaugurating 12 cutting-edge computing pods and autonomous robotics test tracks.",
    icon: "Sparkles"
  },
  {
    year: "2026",
    title: "Ranked #1 Innovation Campus in the Region",
    description: "Celebrating 41 years of pedagogical excellence, zero-carbon sustainability, and 50,000+ alumni driving global industry breakthroughs.",
    icon: "Trophy"
  }
];

export const LEADERSHIP: Leader[] = [
  {
    name: "Dr. Abishek K. Raman",
    role: "Founder & Chancellor",
    credentials: "Ph.D. in High-Energy Systems (MIT), D.Litt. (Hon.), Fellow of Royal Academy",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80",
    bio: "Visionary educator, philanthropist, and author with four decades of commitment to equal-access STEM education and human-centered innovation.",
    message: "At Abishek University, our ambition is not merely to confer degrees, but to awaken ethical intellects capable of navigating the frontier challenges of our century."
  },
  {
    name: "Prof. Eleanor Vance",
    role: "Vice-Chancellor",
    credentials: "Ph.D. in Computational Economics (Stanford), M.Sc. (Oxford)",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80",
    bio: "Pioneered transformative digital curriculum integration, cross-continental academic credit transfers, and industry-sponsored incubator labs.",
    message: "We prepare our scholars to be agile thinkers who lead with scientific evidence, creative daring, and empathy."
  },
  {
    name: "Dr. Marcus Sterling",
    role: "Dean of Academic Affairs & Admissions",
    credentials: "Ph.D. in Applied Mathematics (Cambridge)",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80",
    bio: "Oversees university curriculum modernization, student academic mentoring frameworks, and international scholarship allotments.",
    message: "Our admissions policy looks beyond standardized test scores to identify curiosity, resilience, and problem-solving passion."
  },
  {
    name: "Dr. Sunita Chen",
    role: "Dean of Research & Innovation",
    credentials: "Ph.D. in Bio-Robotics (ETH Zurich), IEEE Fellow",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=600&q=80",
    bio: "Directs 18 interdisciplinary research clusters and manages AU's $60M+ annual industry-funded research sponsorships.",
    message: "Every AU undergraduate participates in direct lab research from their very first year."
  }
];

export const FACILITIES: Facility[] = [
  {
    id: "labs",
    tabTitle: "Smart Labs & Computing",
    title: "High-Tech Labs & AI Supercomputing Hub",
    tagline: "Where theoretical mathematics translates into deployed planetary solutions",
    description: "Equipped with 250+ enterprise GPU clusters, cleanroom nano-fabrication facilities, anechoic chambers, and humanoid robotics assembly arenas accessible 24/7 to faculty and student researchers.",
    image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "NVIDIA DGX Supercomputing Cluster with 100Gbps InfiniBand",
      "Robotics Simulation Arena with Motion-Capture Tracking",
      "Biotechnology Cleanrooms (Class 10,000 Certified)",
      "Dedicated 24/7 Hardware Makerspace with 3D SLA Printers"
    ],
    stats: [
      { label: "Lab Workstations", value: "850+" },
      { label: "Patent Filings / Yr", value: "38+" },
      { label: "Lab Availability", value: "24 / 7" }
    ]
  },
  {
    id: "library",
    tabTitle: "Central Digital Library",
    title: "Sir Arthur Knowledge Hub & Collaborative Commons",
    tagline: "Over 2.4 million physical volumes, journal archives, and quiet study pods",
    description: "A five-story architectural marvel combining soundproof collaborative studios, digital thesis repositories, high-speed fiber terminals, and automated book retrieval robotics.",
    image: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "2.4 Million Print Volumes & 18 Million Online E-Books",
      "Direct IEEE, Springer, ACM, and Nature Full-Text Access",
      "120 Private Acoustic Video-Conferencing Study Pods",
      "Rare Manuscripts & Special University Archives Gallery"
    ],
    stats: [
      { label: "Study Capacity", value: "3,200 Seats" },
      { label: "Online Journals", value: "45,000+" },
      { label: "Daily Footfall", value: "6,500+" }
    ]
  },
  {
    id: "sports",
    tabTitle: "Sports & Olympic Arena",
    title: "Phoenix Olympic Sports Complex & Wellness Center",
    tagline: "Nurturing collegiate champions, physical vitality, and teamwork",
    description: "Houses an Olympic-standard 50-meter temperature-controlled swimming pool, indoor hardwood basketball arena, FIFA-certified turf soccer stadium, 8 synthetic tennis courts, and sports physiotherapy clinic.",
    image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "50m Heated Olympic Swimming Pool with Digital Touchpads",
      "FIFA-standard Natural Grass Soccer Stadium with 12,000 Seats",
      "Full Fitness Conditioning Gym with Certified Kinesiologists",
      "40+ Competitive Intramural Leagues & Student Athletic Clubs"
    ],
    stats: [
      { label: "Olympic Disciplines", value: "18 Sports" },
      { label: "National Medals", value: "140+" },
      { label: "Acreage Dedicated", value: "32 Acres" }
    ]
  },
  {
    id: "hostel",
    tabTitle: "Hostels & Green Campus",
    title: "Eco-Friendly Residential Villages & Botanical Living",
    tagline: "A safe, vibrant home away from home powered by 100% solar energy",
    description: "Designed around lush courtyards, our 6 modern residence halls offer high-speed Wi-Fi, air-conditioned single/double suites, multi-cuisine dining commons, student lounges, and round-the-clock security.",
    image: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "Net-Zero Solar-Powered Residence Halls with Rainwater Harvesting",
      "Multi-Cuisine Organic Dining Commons (Vegetarian & Halal options)",
      "24/7 On-Campus Health Clinic & Paramedic Ambulance Bay",
      "Automated Laundry, High-Speed Mesh Wi-Fi, and Recreation Rooms"
    ],
    stats: [
      { label: "Residential Students", value: "8,200" },
      { label: "Green Cover", value: "65% of Campus" },
      { label: "Security Staffing", value: "24/7 Patrols" }
    ]
  }
];

export const TESTIMONIALS: StudentTestimonial[] = [
  {
    id: "test-1",
    name: "Aarav Sharma",
    program: "B.Tech Artificial Intelligence '25",
    year: "Final Year Scholar",
    avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=400&q=80",
    quote: "The direct mentorship from Chancellor Abishek and the access to the DGX supercomputing cluster allowed our student team to publish two papers at NeurIPS before graduation.",
    rating: 5,
    currentCompany: "Incoming Research Fellow at DeepMind"
  },
  {
    id: "test-2",
    name: "Samantha Brooks",
    program: "Global MBA '24",
    year: "Alumna",
    avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&q=80",
    quote: "AU's venture incubator funded our health-tech prototype right on campus. The cross-disciplinary culture between engineering and business is unlike anywhere else in higher education.",
    rating: 5,
    currentCompany: "Founder, VitalScale Solutions"
  },
  {
    id: "test-3",
    name: "Dr. Kenji Sato",
    program: "Ph.D. in Autonomous Systems '23",
    year: "Alumnus",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80",
    quote: "The academic freedom, generous doctoral stipend, and international conference sponsorship made my 4 years at Abishek University profoundly transformative.",
    rating: 5,
    currentCompany: "Senior Systems Lead, Tesla Autopilot"
  },
  {
    id: "test-4",
    name: "Priyanka Patel",
    program: "B.Sc Computer Science '26",
    year: "Junior Year Scholar",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80",
    quote: "Living on the green eco-campus while participating in the Hackathon club built friendships that will last a lifetime. The campus feels safe, inspiring, and truly inclusive.",
    rating: 5,
    currentCompany: "Software Engineering Intern, Google"
  }
];

export const CAMPUS_HOTSPOTS: CampusHotspot[] = [
  {
    id: "hotspot-1",
    name: "Grand Chancellor Quad & Heritage Dome",
    category: "Administrative & Historic",
    tag: "Heart of the University",
    image: "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=1000&q=80",
    description: "The historic administrative nerve center featuring Neo-classical arches, the Founder's bronze statue, ceremonial graduation lawn, and University Bell Tower.",
    highlights: ["Founded in 1985", "Convocation Grounds", "Bell tolls hourly", "Centennial time capsule"],
    x: 28,
    y: 35
  },
  {
    id: "hotspot-2",
    name: "Quantum AI & Robotics Innovation Complex",
    category: "STEM Research",
    tag: "Next-Gen Discovery",
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1000&q=80",
    description: "A 6-story glass and steel architectural landmark housing neuromorphic compute pods, drone flight cages, and cleanroom fabrication suites.",
    highlights: ["Class 10k Cleanrooms", "Drone flight testing cage", "Industry sponsored pods", "Patent facilitation center"],
    x: 72,
    y: 28
  },
  {
    id: "hotspot-3",
    name: "Phoenix Olympic Arena & Aquatic Pavilion",
    category: "Athletics & Recreation",
    tag: "Championship Grounds",
    image: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=1000&q=80",
    description: "Comprehensive athletic destination with 50m heated pool, 12,000-capacity soccer pitch, tennis courts, and sports medicine clinic.",
    highlights: ["Olympic sized pool", "12,000 seat stadium", "Floodlit tennis courts", "Sports nutrition bar"],
    x: 80,
    y: 75
  },
  {
    id: "hotspot-4",
    name: "Sir Arthur Digital Library & Commons",
    category: "Learning & Archives",
    tag: "24/7 Intellectual Sanctuary",
    image: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=1000&q=80",
    description: "Five stories of quiet research stacks, robotic book retrievers, digital thesis collections, and sun-lit rooftop study terraces.",
    highlights: ["2.4M physical volumes", "Acoustic private pods", "Starbucks coffee lounge", "Rare books vault"],
    x: 22,
    y: 72
  },
  {
    id: "hotspot-5",
    name: "Solar Eco-Village & Student Living Hub",
    category: "Residential Living",
    tag: "Sustainable Home",
    image: "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80",
    description: "Lush botanical gardens, carbon-neutral residential halls, organic farm-to-table dining commons, and student recreation courtyards.",
    highlights: ["100% solar powered", "Farm-to-table cafeteria", "Organic community orchard", "Night shuttle hub"],
    x: 52,
    y: 54
  }
];

export const FAQS: FAQItem[] = [
  {
    id: "faq-1",
    category: "Admissions",
    question: "What are the key admission deadlines for Fall 2026?",
    answer: "Early Action applications close on November 15, 2026. Regular Decision deadline is January 15, 2027. Rolling admissions for international candidates remain open until seats are filled."
  },
  {
    id: "faq-2",
    category: "Admissions",
    question: "How do I check the status of my submitted application?",
    answer: "Once you submit your application through our portal, you will be assigned a unique Application ID (e.g., AU-2026-XXXXX). You can enter this ID in the 'Check Application Status' tool anytime to see your real-time review progress."
  },
  {
    id: "faq-3",
    category: "Financial & Scholarships",
    question: "Does Abishek University offer merit-based scholarships?",
    answer: "Yes! We offer the Chancellor's Merit Award covering up to 100% tuition for students in the top 5% of their graduating high school class or with exceptional standardized scores. In addition, Dean's Scholarships (25% - 50%) are automatically evaluated with every application."
  },
  {
    id: "faq-4",
    category: "Academics",
    question: "Can undergraduate students participate in faculty research?",
    answer: "Absolutely. Through our AU Undergraduate Research Apprenticeship (AURA) program, students can join funded faculty research labs as early as their first semester, earning both academic credits and monthly stipends."
  },
  {
    id: "faq-5",
    category: "Campus Life",
    question: "Is on-campus accommodation guaranteed for first-year students?",
    answer: "Yes, all admitted full-time first-year undergraduate scholars are guaranteed modern residence housing in our Net-Zero Eco Villages with full meal plans and 24/7 security."
  },
  {
    id: "faq-6",
    category: "Financial & Scholarships",
    question: "How are semester tuition fees calculated?",
    answer: "Tuition is billed per semester based on your degree level, course credits, chosen residential suite type, and meal plan. Use our interactive Tuition Fee Calculator to see an immediate estimated breakdown."
  }
];
