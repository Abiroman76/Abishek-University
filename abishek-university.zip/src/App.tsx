/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Announcements from './components/Announcements';
import AboutSection from './components/AboutSection';
import AcademicsSection from './components/AcademicsSection';
import CampusLifeSection from './components/CampusLifeSection';
import AdmissionsSection from './components/AdmissionsSection';
import FeeCalculator from './components/FeeCalculator';
import VirtualTour from './components/VirtualTour';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import TrackApplicationModal from './components/TrackApplicationModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [trackModalOpen, setTrackModalOpen] = useState<boolean>(false);
  const [preselectedProgram, setPreselectedProgram] = useState<string | undefined>(undefined);
  const [preselectedDegree, setPreselectedDegree] = useState<string | undefined>(undefined);

  const navigateTo = (sectionId: string) => {
    setActiveTab(sectionId);
    const elem = document.getElementById(sectionId);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleApplyForProgram = (programTitle: string, degreeLevel?: string) => {
    setPreselectedProgram(programTitle);
    if (degreeLevel) setPreselectedDegree(degreeLevel);
    navigateTo('admissions');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col selection:bg-amber-500 selection:text-white">
      {/* Sticky Top Header */}
      <Header 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        onOpenTrackModal={() => setTrackModalOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-1 flex flex-col">
        {/* 1. Hero Section & Quick Stats Counter */}
        <Hero 
          onExplorePrograms={() => navigateTo('academics')}
          onApplyNow={() => navigateTo('admissions')}
          onOpenTour={() => navigateTo('tour')}
        />

        {/* 2. Announcements, Live Circulars & Quick Area Links */}
        <Announcements onNavigateTo={navigateTo} />

        {/* 3. About Us, Chancellor's Welcome, Mission & Milestones Timeline */}
        <AboutSection />

        {/* 4. Academics & Program Finder (Interactive Degree & Field Filter + Syllabus Modal) */}
        <AcademicsSection onSelectProgramToApply={handleApplyForProgram} />

        {/* 5. Campus Features & Facilities Tabbed Gallery + Testimonials */}
        <CampusLifeSection />

        {/* 6. Working Online Admission Application Portal with Multi-Step Form */}
        <AdmissionsSection 
          preselectedProgram={preselectedProgram}
          preselectedDegree={preselectedDegree}
        />

        {/* 7. Tuition Fee & Semester Cost Calculator */}
        <FeeCalculator onApplyWithEstimates={(prog) => handleApplyForProgram(prog)} />

        {/* 8. Virtual Campus Tour Preview with Interactive Hotspots */}
        <VirtualTour />

        {/* 9. Contact Us & Interactive FAQ Accordion */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer onNavigateTo={navigateTo} />

      {/* Quick Track Application Modal (Accessible from anywhere) */}
      <TrackApplicationModal 
        isOpen={trackModalOpen} 
        onClose={() => setTrackModalOpen(false)} 
      />
    </div>
  );
}

