export type DegreeLevel = 'All' | 'Undergraduate' | 'Postgraduate' | 'Doctorate';

export type AcademicField = 
  | 'All' 
  | 'Engineering & Tech' 
  | 'Business' 
  | 'Medicine' 
  | 'Humanities' 
  | 'Artificial Intelligence';

export interface SyllabusSemester {
  semester: number;
  title: string;
  courses: string[];
}

export interface AcademicProgram {
  id: string;
  title: string;
  degree: 'Undergraduate' | 'Postgraduate' | 'Doctorate';
  field: 'Engineering & Tech' | 'Business' | 'Medicine' | 'Humanities' | 'Artificial Intelligence';
  duration: string;
  eligibility: string;
  credits: number;
  tuitionPerSemester: number;
  shortDesc: string;
  careerOutlook: string;
  badge?: string;
  iconName: string;
  syllabus: SyllabusSemester[];
}

export interface Announcement {
  id: string;
  title: string;
  date: string;
  category: 'Academic' | 'Admissions' | 'Events' | 'Research';
  summary: string;
  urgent?: boolean;
}

export interface Milestone {
  year: string;
  title: string;
  description: string;
  icon: string;
}

export interface Leader {
  name: string;
  role: string;
  credentials: string;
  image: string;
  bio: string;
  message?: string;
}

export interface Facility {
  id: string;
  tabTitle: string;
  title: string;
  tagline: string;
  description: string;
  image: string;
  highlights: string[];
  stats: { label: string; value: string }[];
}

export interface StudentTestimonial {
  id: string;
  name: string;
  program: string;
  year: string;
  avatar: string;
  quote: string;
  rating: number;
  currentCompany?: string;
}

export interface AdmissionApplication {
  id: string;
  submittedAt: string;
  status: 'Pending Review' | 'Under Academic Verification' | 'Interview Scheduled' | 'Admission Granted';
  personal: {
    fullName: string;
    email: string;
    phone: string;
    dob: string;
    gender: string;
    address: string;
    nationality: string;
  };
  academic: {
    previousInstitution: string;
    highestQualification: string;
    gpa: string;
    desiredDegree: string;
    desiredMajor: string;
    graduationYear: string;
  };
  documents: {
    transcriptFile?: string;
    identityProofFile?: string;
    sopFile?: string;
  };
}

export interface CampusHotspot {
  id: string;
  name: string;
  category: string;
  tag: string;
  image: string;
  description: string;
  highlights: string[];
  x: number; // percentage
  y: number; // percentage
}

export interface FAQItem {
  id: string;
  category: 'Admissions' | 'Academics' | 'Financial & Scholarships' | 'Campus Life';
  question: string;
  answer: string;
}
